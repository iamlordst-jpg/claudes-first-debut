package com.saiyanlegacy;

import java.util.UUID;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LightningBolt;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.player.Abilities;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import org.joml.Vector3f;

public final class KiActions {
    private static final UUID SPEED_UUID = UUID.fromString("5f1a7c1e-3b0d-4e7a-9a53-2c6f0d9e4b11");

    private KiActions() {}

    // ------------------------------------------------------------------ helpers

    public static void msg(ServerPlayer p, String text) {
        p.displayClientMessage(Component.literal(text), true);
    }

    public static void sync(ServerPlayer p, PlayerKi k) {
        ModNetwork.toPlayer(p, new SyncPacket(k.ki, k.maxKi(), k.power, k.form.ordinal(), k.flying, k.charging));
    }

    // ------------------------------------------------------------------ dispatch

    public static void perform(ServerPlayer p, ActionPacket.Action action) {
        PlayerKi k = PlayerKi.of(p);
        if (k == null) return;
        switch (action) {
            case CHARGE_START -> k.charging = true;
            case CHARGE_STOP -> k.charging = false;
            case BLAST -> blast(p, k);
            case KAME_START -> {
                if (k.ki >= 25) {
                    k.kameCharging = true;
                    k.kameTicks = 0;
                } else {
                    msg(p, "Not enough ki for a Kamehameha.");
                }
            }
            case KAME_RELEASE -> {
                if (k.kameCharging) fireKame(p, k);
                k.kameCharging = false;
                k.kameTicks = 0;
            }
            case TRANSFORM_UP -> transform(p, k, 1);
            case TRANSFORM_DOWN -> transform(p, k, -1);
            case TOGGLE_FLY -> toggleFly(p, k);
            case BLINK -> blink(p, k);
        }
        sync(p, k);
    }

    // ------------------------------------------------------------------ per-tick

    public static void tick(ServerPlayer p, PlayerKi k) {
        ServerLevel lvl = p.serverLevel();
        double max = k.maxKi();

        k.ki = Math.min(max, k.ki + (k.charging ? 0.6 : 0.04));

        if (k.charging) {
            if (p.tickCount % 20 == 0) k.power += 2; // training: charging slowly raises power level
            if (p.tickCount % 2 == 0) {
                aura(lvl, p, k.form.aura, 4, 1.2f);
                lvl.sendParticles(ParticleTypes.ELECTRIC_SPARK, p.getX(), p.getY() + 1.0, p.getZ(), 2, 0.5, 0.8, 0.5, 0.05);
            }
        }

        if (k.form != Form.BASE) {
            k.ki -= k.form.drain / 20.0;
            if (p.tickCount % 3 == 0) aura(lvl, p, k.form.aura, 3, 1.4f);
            if (k.ki <= 0) {
                k.ki = 0;
                setForm(p, k, Form.BASE);
                msg(p, "You ran out of ki and powered down.");
            }
        }

        if (k.flying) {
            k.ki -= 0.08;
            p.fallDistance = 0;
            if (k.ki <= 0) {
                k.ki = 0;
                setFlying(p, k, false);
                msg(p, "Out of ki - you can no longer fly.");
            }
        }

        if (k.kameCharging) {
            if (k.ki < 20) {
                k.kameCharging = false;
                k.kameTicks = 0;
                msg(p, "Kamehameha cancelled - out of ki.");
            } else {
                k.kameTicks = Math.min(100, k.kameTicks + 1);
                Vec3 pos = p.getEyePosition().add(p.getLookAngle().scale(1.6)).add(0, -0.5, 0);
                float size = Mth.clamp(0.8f + k.kameTicks / 25.0f, 0.8f, 4.0f);
                lvl.sendParticles(new DustParticleOptions(new Vector3f(0.3f, 0.7f, 1.0f), size),
                        pos.x, pos.y, pos.z, 2, 0.1, 0.1, 0.1, 0);
                if (k.kameTicks % 4 == 0) {
                    lvl.sendParticles(ParticleTypes.ELECTRIC_SPARK, pos.x, pos.y, pos.z, 3, 0.3, 0.3, 0.3, 0.1);
                }
            }
        }

        if (p.tickCount % 5 == 0) sync(p, k);
    }

    private static void aura(ServerLevel lvl, ServerPlayer p, float[] c, int count, float scale) {
        DustParticleOptions opt = new DustParticleOptions(new Vector3f(c[0], c[1], c[2]), scale);
        for (int i = 0; i < count; i++) {
            double x = p.getX() + (p.getRandom().nextDouble() - 0.5) * 1.2;
            double y = p.getY() + p.getRandom().nextDouble() * 2.0;
            double z = p.getZ() + (p.getRandom().nextDouble() - 0.5) * 1.2;
            lvl.sendParticles(opt, x, y, z, 1, 0, 0.1, 0, 0.02);
        }
    }

    // ------------------------------------------------------------------ ki blast

    private static void blast(ServerPlayer p, PlayerKi k) {
        if (p.tickCount < k.nextBlastTick) return;
        if (k.ki < 4) {
            msg(p, "Not enough ki.");
            return;
        }
        k.ki -= 4;
        k.nextBlastTick = p.tickCount + 8;
        KiBlastEntity blast = new KiBlastEntity(p.level(), p);
        blast.setDamage((float) (5.0 * k.damageMult()));
        blast.setFormId(k.form.ordinal());
        blast.shootFromRotation(p, p.getXRot(), p.getYRot(), 0.0F, 2.5F, 0.0F);
        p.level().addFreshEntity(blast);
        p.level().playSound(null, p.blockPosition(), SoundEvents.FIRECHARGE_USE, SoundSource.PLAYERS, 0.8f, 1.6f);
    }

    // ------------------------------------------------------------------ kamehameha

    private static double distToSegment(Vec3 pt, Vec3 a, Vec3 b) {
        Vec3 ab = b.subtract(a);
        double lenSqr = ab.lengthSqr();
        if (lenSqr < 1.0E-4) return pt.distanceTo(a);
        double t = Mth.clamp(pt.subtract(a).dot(ab) / lenSqr, 0.0, 1.0);
        return pt.distanceTo(a.add(ab.scale(t)));
    }

    private static void fireKame(ServerPlayer p, PlayerKi k) {
        int ticks = k.kameTicks;
        double cost = 20 + ticks * 0.5;
        if (k.ki < cost) {
            ticks = (int) ((k.ki - 20) / 0.5);
            cost = 20 + ticks * 0.5;
        }
        if (ticks < 10) {
            msg(p, "Kamehameha fizzled - hold the key longer!");
            return;
        }
        k.ki -= cost;
        double power = ticks / 100.0;

        ServerLevel lvl = p.serverLevel();
        Vec3 dir = p.getLookAngle();
        Vec3 start = p.getEyePosition().add(dir.scale(1.0)).add(0, -0.3, 0);
        double range = 30 + 60 * power;
        Vec3 end = start.add(dir.scale(range));
        BlockHitResult hit = lvl.clip(new ClipContext(start, end, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, p));
        boolean hitBlock = hit.getType() != HitResult.Type.MISS;
        Vec3 realEnd = hitBlock ? hit.getLocation() : end;
        double len = start.distanceTo(realEnd);

        float[] c = k.form == Form.BASE ? new float[]{0.3f, 0.7f, 1.0f} : k.form.aura;
        DustParticleOptions core = new DustParticleOptions(new Vector3f(c[0], c[1], c[2]), (float) Mth.clamp(1.5 + 2 * power, 0.5, 4.0));
        DustParticleOptions white = new DustParticleOptions(new Vector3f(1.0f, 1.0f, 1.0f), 1.2f);
        for (double d = 0; d <= len; d += 0.6) {
            Vec3 pt = start.add(dir.scale(d));
            lvl.sendParticles(core, pt.x, pt.y, pt.z, 2, 0.2, 0.2, 0.2, 0);
            lvl.sendParticles(white, pt.x, pt.y, pt.z, 1, 0.05, 0.05, 0.05, 0);
        }

        float dmg = (float) ((12 + 38 * power) * k.damageMult());
        double radius = 1.5 + 2 * power;
        AABB box = new AABB(start, realEnd).inflate(radius + 1);
        k.suppressMult = true;
        try {
            for (LivingEntity e : lvl.getEntitiesOfClass(LivingEntity.class, box, x -> x != p && x.isAlive())) {
                if (distToSegment(e.getBoundingBox().getCenter(), start, realEnd) <= radius) {
                    e.hurt(p.damageSources().indirectMagic(p, p), dmg);
                    e.push(dir.x * 1.2, 0.35, dir.z * 1.2);
                    e.hurtMarked = true;
                }
            }
        } finally {
            k.suppressMult = false;
        }

        if (hitBlock && len > 4.0) {
            lvl.explode(p, realEnd.x, realEnd.y, realEnd.z, (float) (2.0 + 4.0 * power), Level.ExplosionInteraction.MOB);
        }
        lvl.playSound(null, p.blockPosition(), SoundEvents.BEACON_ACTIVATE, SoundSource.PLAYERS, 1.5f, 0.6f);
        lvl.playSound(null, p.blockPosition(), SoundEvents.GENERIC_EXPLODE, SoundSource.PLAYERS, 0.8f, 1.4f);
    }

    // ------------------------------------------------------------------ forms

    private static void transform(ServerPlayer p, PlayerKi k, int dir) {
        Form[] all = Form.values();
        int idx = k.form.ordinal() + dir;
        if (idx < 0) {
            msg(p, "Already in base form.");
            return;
        }
        if (idx >= all.length) {
            msg(p, "You have reached your highest form.");
            return;
        }
        Form target = all[idx];
        if (dir > 0) {
            if (k.power < target.minPower) {
                msg(p, target.displayName + " needs " + String.format("%,d", target.minPower) + " Power Level.");
                return;
            }
            if (k.ki < 25) {
                msg(p, "Not enough ki to transform.");
                return;
            }
            k.ki -= 10;
        }
        setForm(p, k, target);
        msg(p, target.displayName);
    }

    public static void setForm(ServerPlayer p, PlayerKi k, Form f) {
        k.form = f;
        applySpeed(p, k);
        if (k.flying) applyFlight(p, k);
        ServerLevel lvl = p.serverLevel();
        aura(lvl, p, f.aura, 40, 1.8f);
        lvl.sendParticles(ParticleTypes.FLASH, p.getX(), p.getY() + 1.0, p.getZ(), 1, 0, 0, 0, 0);
        if (f.ordinal() >= Form.SUPER_SAIYAN.ordinal()) {
            LightningBolt bolt = EntityType.LIGHTNING_BOLT.create(lvl);
            if (bolt != null) {
                bolt.moveTo(p.position());
                bolt.setVisualOnly(true);
                lvl.addFreshEntity(bolt);
            }
        }
        lvl.playSound(null, p.blockPosition(), SoundEvents.BEACON_POWER_SELECT, SoundSource.PLAYERS, 1.2f, 0.7f);
        sync(p, k);
    }

    public static void applySpeed(ServerPlayer p, PlayerKi k) {
        AttributeInstance speed = p.getAttribute(Attributes.MOVEMENT_SPEED);
        if (speed == null) return;
        speed.removeModifier(SPEED_UUID);
        if (k.form.speed > 0) {
            speed.addTransientModifier(new AttributeModifier(SPEED_UUID, "saiyanlegacy.form",
                    k.form.speed, AttributeModifier.Operation.MULTIPLY_TOTAL));
        }
    }

    // ------------------------------------------------------------------ flight

    private static void toggleFly(ServerPlayer p, PlayerKi k) {
        if (k.flying) {
            setFlying(p, k, false);
        } else if (k.ki < 10) {
            msg(p, "Not enough ki to fly.");
        } else {
            setFlying(p, k, true);
        }
    }

    public static void setFlying(ServerPlayer p, PlayerKi k, boolean on) {
        k.flying = on;
        applyFlight(p, k);
    }

    private static void applyFlight(ServerPlayer p, PlayerKi k) {
        Abilities ab = p.getAbilities();
        if (k.flying) {
            ab.mayfly = true;
            ab.flying = true;
            ab.setFlyingSpeed(0.06f + (float) k.form.speed * 0.05f);
        } else {
            if (!p.isCreative() && !p.isSpectator()) {
                ab.mayfly = false;
                ab.flying = false;
            }
            ab.setFlyingSpeed(0.05f);
        }
        p.onUpdateAbilities();
    }

    // ------------------------------------------------------------------ blink

    private static void blink(ServerPlayer p, PlayerKi k) {
        if (k.ki < 12) {
            msg(p, "Not enough ki to blink.");
            return;
        }
        ServerLevel lvl = p.serverLevel();
        Vec3 dir = p.getLookAngle();
        Vec3 eye = p.getEyePosition();
        double maxDist = 16.0;
        BlockHitResult hit = lvl.clip(new ClipContext(eye, eye.add(dir.scale(maxDist)),
                ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, p));
        if (hit.getType() != HitResult.Type.MISS) maxDist = eye.distanceTo(hit.getLocation());

        for (double d = maxDist; d >= 1.5; d -= 1.0) {
            AABB moved = p.getBoundingBox().move(dir.scale(d));
            if (lvl.noCollision(p, moved)) {
                lvl.sendParticles(ParticleTypes.REVERSE_PORTAL, p.getX(), p.getY() + 1.0, p.getZ(), 30, 0.3, 0.6, 0.3, 0.2);
                Vec3 to = p.position().add(dir.scale(d));
                p.teleportTo(to.x, to.y, to.z);
                p.fallDistance = 0;
                lvl.sendParticles(ParticleTypes.REVERSE_PORTAL, to.x, to.y + 1.0, to.z, 30, 0.3, 0.6, 0.3, 0.2);
                lvl.playSound(null, p.blockPosition(), SoundEvents.ENDERMAN_TELEPORT, SoundSource.PLAYERS, 1.0f, 1.5f);
                k.ki -= 12;
                return;
            }
        }
        msg(p, "No room to blink there.");
    }
}
