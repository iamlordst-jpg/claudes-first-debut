package com.saiyanlegacy;

import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

public class DragonRadarItem extends Item {
    private static final String[] COMPASS = {"East", "South-East", "South", "South-West", "West", "North-West", "North", "North-East"};

    public DragonRadarItem(Properties props) {
        super(props);
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (!level.isClientSide() && player instanceof ServerPlayer sp) {
            Vec3 me = sp.position();
            Vec3 best = null;
            double bestDist = Double.MAX_VALUE;

            for (ItemEntity ie : level.getEntitiesOfClass(ItemEntity.class, sp.getBoundingBox().inflate(300),
                    e -> e.getItem().getItem() instanceof DragonBallItem)) {
                double d = ie.position().distanceTo(me);
                if (d < bestDist) { bestDist = d; best = ie.position(); }
            }
            for (Player other : level.players()) {
                if (other != sp && DragonBallItem.carries(other)) {
                    double d = other.position().distanceTo(me);
                    if (d < bestDist) { bestDist = d; best = other.position(); }
                }
            }

            if (best == null) {
                KiActions.msg(sp, "No Dragon Ball signal nearby.");
            } else {
                double angle = Math.toDegrees(Math.atan2(best.z - me.z, best.x - me.x));
                int idx = ((int) Math.round(angle / 45.0) % 8 + 8) % 8;
                KiActions.msg(sp, "Dragon Ball signal: " + (int) bestDist + " blocks " + COMPASS[idx]);
            }
        }
        player.getCooldowns().addCooldown(this, 40);
        return InteractionResultHolder.sidedSuccess(stack, level.isClientSide());
    }
}
