package com.saiyanlegacy;

public enum Form {
    //        name                 dmg  def  speed drain/s minPL  hudColor  aura rgb
    BASE("Base",                   1.0, 1.0, 0.0, 0.0, 0,      0xFFFFFF, new float[]{0.75f, 0.9f, 1.0f}),
    KAIOKEN("Kaioken x10",         1.7, 0.8, 0.4, 4.0, 0,      0xFF4040, new float[]{1.0f, 0.1f, 0.1f}),
    SUPER_SAIYAN("Super Saiyan",   2.2, 1.6, 0.5, 1.5, 2500,   0xFFD700, new float[]{1.0f, 0.85f, 0.1f}),
    SUPER_SAIYAN_BLUE("Super Saiyan Blue", 3.5, 2.5, 0.8, 3.0, 25000, 0x40C8FF, new float[]{0.2f, 0.6f, 1.0f});

    public final String displayName;
    public final double damage;
    public final double defense;
    public final double speed;
    public final double drain;
    public final long minPower;
    public final int hudColor;
    public final float[] aura;

    Form(String displayName, double damage, double defense, double speed, double drain,
         long minPower, int hudColor, float[] aura) {
        this.displayName = displayName;
        this.damage = damage;
        this.defense = defense;
        this.speed = speed;
        this.drain = drain;
        this.minPower = minPower;
        this.hudColor = hudColor;
        this.aura = aura;
    }

    public static Form byId(int id) {
        Form[] v = values();
        return v[Math.max(0, Math.min(v.length - 1, id))];
    }
}
