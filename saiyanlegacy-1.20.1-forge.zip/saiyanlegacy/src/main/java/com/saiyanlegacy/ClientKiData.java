package com.saiyanlegacy;

/** Plain holder for the local player's synced stats (read by the HUD). */
public class ClientKiData {
    public static double ki = 100;
    public static double maxKi = 120;
    public static long power = 100;
    public static int form = 0;
    public static boolean flying;
    public static boolean charging;

    public static void set(double ki, double maxKi, long power, int form, boolean flying, boolean charging) {
        ClientKiData.ki = ki;
        ClientKiData.maxKi = maxKi;
        ClientKiData.power = power;
        ClientKiData.form = form;
        ClientKiData.flying = flying;
        ClientKiData.charging = charging;
    }
}
