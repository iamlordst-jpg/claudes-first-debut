package com.saiyanlegacy;

import net.minecraftforge.common.capabilities.Capability;
import net.minecraftforge.common.capabilities.CapabilityManager;
import net.minecraftforge.common.capabilities.CapabilityToken;

public class ModCaps {
    public static final Capability<PlayerKi> KI =
            CapabilityManager.get(new CapabilityToken<PlayerKi>() {});
}
