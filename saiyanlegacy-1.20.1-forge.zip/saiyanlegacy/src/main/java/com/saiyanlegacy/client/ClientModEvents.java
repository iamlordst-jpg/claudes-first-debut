package com.saiyanlegacy.client;

import com.saiyanlegacy.ModEntities;
import com.saiyanlegacy.SaiyanLegacy;
import net.minecraft.client.renderer.entity.ThrownItemRenderer;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.client.event.RegisterGuiOverlaysEvent;
import net.minecraftforge.client.event.RegisterKeyMappingsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = SaiyanLegacy.MODID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class ClientModEvents {
    @SubscribeEvent
    public static void registerKeys(RegisterKeyMappingsEvent event) {
        event.register(KeyBinds.CHARGE);
        event.register(KeyBinds.BLAST);
        event.register(KeyBinds.KAME);
        event.register(KeyBinds.UP);
        event.register(KeyBinds.DOWN);
        event.register(KeyBinds.FLY);
        event.register(KeyBinds.BLINK);
    }

    @SubscribeEvent
    public static void registerRenderers(EntityRenderersEvent.RegisterRenderers event) {
        event.registerEntityRenderer(ModEntities.KI_BLAST.get(), ctx -> new ThrownItemRenderer<>(ctx, 1.5f, true));
    }

    @SubscribeEvent
    public static void registerOverlays(RegisterGuiOverlaysEvent event) {
        event.registerAboveAll("ki_hud", new KiHud());
    }
}
