package com.saiyanlegacy.client;

import com.saiyanlegacy.ActionPacket;
import com.saiyanlegacy.ActionPacket.Action;
import com.saiyanlegacy.ModNetwork;
import com.saiyanlegacy.SaiyanLegacy;
import net.minecraft.client.Minecraft;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = SaiyanLegacy.MODID, value = Dist.CLIENT)
public class ClientForgeEvents {
    private static boolean charging;
    private static boolean kame;

    private static void send(Action a) {
        ModNetwork.toServer(new ActionPacket(a));
    }

    @SubscribeEvent
    public static void onClientTick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;
        Minecraft mc = Minecraft.getInstance();

        boolean inGame = mc.player != null && mc.screen == null;
        boolean wantCharge = inGame && KeyBinds.CHARGE.isDown();
        boolean wantKame = inGame && KeyBinds.KAME.isDown();

        if (mc.player == null) {
            charging = false;
            kame = false;
            return;
        }

        if (wantCharge != charging) {
            charging = wantCharge;
            send(charging ? Action.CHARGE_START : Action.CHARGE_STOP);
        }
        if (wantKame != kame) {
            kame = wantKame;
            send(kame ? Action.KAME_START : Action.KAME_RELEASE);
        }

        if (!inGame) return;
        while (KeyBinds.BLAST.consumeClick()) send(Action.BLAST);
        while (KeyBinds.UP.consumeClick()) send(Action.TRANSFORM_UP);
        while (KeyBinds.DOWN.consumeClick()) send(Action.TRANSFORM_DOWN);
        while (KeyBinds.FLY.consumeClick()) send(Action.TOGGLE_FLY);
        while (KeyBinds.BLINK.consumeClick()) send(Action.BLINK);
    }
}
