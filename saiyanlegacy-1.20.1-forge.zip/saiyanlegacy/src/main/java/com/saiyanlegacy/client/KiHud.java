package com.saiyanlegacy.client;

import com.saiyanlegacy.ClientKiData;
import com.saiyanlegacy.Form;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.util.Mth;
import net.minecraftforge.client.gui.overlay.ForgeGui;
import net.minecraftforge.client.gui.overlay.IGuiOverlay;

public class KiHud implements IGuiOverlay {
    @Override
    public void render(ForgeGui gui, GuiGraphics g, float partialTick, int width, int height) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.options.hideGui || mc.player == null || mc.player.isSpectator()) return;
        Font font = mc.font;

        int x = 10;
        int y = height - 52;
        int barW = 100;
        Form form = Form.byId(ClientKiData.form);

        double ratio = ClientKiData.maxKi <= 0 ? 0 : Mth.clamp(ClientKiData.ki / ClientKiData.maxKi, 0.0, 1.0);
        g.fill(x - 1, y - 1, x + barW + 1, y + 9, 0xAA000000);
        g.fill(x, y, x + (int) (barW * ratio), y + 8, 0xFF000000 | (form == Form.BASE ? 0x2E9BFF : form.hudColor));

        g.drawString(font, "Ki " + (int) ClientKiData.ki + "/" + (int) ClientKiData.maxKi, x, y - 11, 0xFFFFFFFF);
        g.drawString(font, "PL " + String.format("%,d", ClientKiData.power), x, y + 12, 0xFFFFD700);
        g.drawString(font, form.displayName, x, y + 22, 0xFF000000 | form.hudColor);

        String status = "";
        if (ClientKiData.charging) status += "[Charging] ";
        if (ClientKiData.flying) status += "[Flying]";
        if (!status.isEmpty()) g.drawString(font, status, x, y + 32, 0xFFAAAAAA);
    }
}
