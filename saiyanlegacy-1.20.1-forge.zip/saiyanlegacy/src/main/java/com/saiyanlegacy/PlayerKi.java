package com.saiyanlegacy;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.entity.player.Player;

public class PlayerKi {
    // saved
    public double ki = 100;
    public long power = 100;

    // runtime only
    public Form form = Form.BASE;
    public boolean flying;
    public boolean charging;
    public boolean kameCharging;
    public int kameTicks;
    public long nextBlastTick;
    public boolean suppressMult;

    public static PlayerKi of(Player p) {
        return p.getCapability(ModCaps.KI).resolve().orElse(null);
    }

    public double maxKi() {
        return 100 + 2 * Math.sqrt(power);
    }

    public double damageMult() {
        return form.damage * (1 + Math.sqrt(power) / 40.0);
    }

    public double defenseMult() {
        return form.defense * (1 + Math.sqrt(power) / 80.0);
    }

    public CompoundTag save() {
        CompoundTag tag = new CompoundTag();
        tag.putDouble("ki", ki);
        tag.putLong("power", power);
        return tag;
    }

    public void load(CompoundTag tag) {
        if (tag.contains("ki")) ki = tag.getDouble("ki");
        if (tag.contains("power")) power = tag.getLong("power");
    }

    public void copyFrom(PlayerKi old, boolean death) {
        power = old.power;
        ki = death ? maxKi() : old.ki;
    }
}
