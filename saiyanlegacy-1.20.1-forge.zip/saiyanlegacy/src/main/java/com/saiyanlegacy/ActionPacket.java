package com.saiyanlegacy;

import java.util.function.Supplier;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkEvent;

public class ActionPacket {
    public enum Action {
        CHARGE_START, CHARGE_STOP, BLAST, KAME_START, KAME_RELEASE,
        TRANSFORM_UP, TRANSFORM_DOWN, TOGGLE_FLY, BLINK
    }

    private final Action action;

    public ActionPacket(Action action) {
        this.action = action;
    }

    public static void encode(ActionPacket msg, FriendlyByteBuf buf) {
        buf.writeEnum(msg.action);
    }

    public static ActionPacket decode(FriendlyByteBuf buf) {
        return new ActionPacket(buf.readEnum(Action.class));
    }

    public static void handle(ActionPacket msg, Supplier<NetworkEvent.Context> ctx) {
        NetworkEvent.Context c = ctx.get();
        c.enqueueWork(() -> {
            ServerPlayer player = c.getSender();
            if (player != null) KiActions.perform(player, msg.action);
        });
        c.setPacketHandled(true);
    }
}
