package com.saiyanlegacy;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Rarity;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModItems {
    public static final DeferredRegister<Item> ITEMS =
            DeferredRegister.create(ForgeRegistries.ITEMS, SaiyanLegacy.MODID);
    public static final DeferredRegister<CreativeModeTab> TABS =
            DeferredRegister.create(Registries.CREATIVE_MODE_TAB, SaiyanLegacy.MODID);

    public static final RegistryObject<Item> SENZU_BEAN = ITEMS.register("senzu_bean",
            () -> new SenzuBeanItem(new Item.Properties().stacksTo(16).rarity(Rarity.RARE)));
    public static final RegistryObject<Item> DRAGON_RADAR = ITEMS.register("dragon_radar",
            () -> new DragonRadarItem(new Item.Properties().stacksTo(1)));
    public static final RegistryObject<Item> KI_BLAST = ITEMS.register("ki_blast",
            () -> new Item(new Item.Properties()));

    public static final List<RegistryObject<Item>> DRAGON_BALLS = new ArrayList<>();

    static {
        for (int i = 1; i <= 7; i++) {
            final int stars = i;
            DRAGON_BALLS.add(ITEMS.register("dragon_ball_" + i,
                    () -> new DragonBallItem(stars, new Item.Properties().stacksTo(1).rarity(Rarity.EPIC))));
        }
    }

    public static final RegistryObject<CreativeModeTab> TAB = TABS.register("main",
            () -> CreativeModeTab.builder()
                    .title(Component.translatable("itemGroup.saiyanlegacy"))
                    .icon(() -> DRAGON_BALLS.get(3).get().getDefaultInstance())
                    .displayItems((params, output) -> {
                        output.accept(SENZU_BEAN.get());
                        output.accept(DRAGON_RADAR.get());
                        for (RegistryObject<Item> ball : DRAGON_BALLS) output.accept(ball.get());
                    })
                    .build());
}
