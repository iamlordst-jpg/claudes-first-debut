package com.saiyanlegacy;

import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.projectile.ThrowableItemProjectile;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;
import org.joml.Vector3f;

public class KiBlastEntity extends ThrowableItemProjectile {
    private static final EntityDataAccessor<Integer> FORM =
            SynchedEntityData.defineId(KiBlastEntity.class, EntityDataSerializers.INT);

    private float damage = 5.0f;

    public KiBlastEntity(EntityType<? extends KiBlastEntity> type, Level level) {
        super(type, level);
    }

    public KiBlastEntity(Level level, LivingEntity owner) {
        super(ModEntities.KI_BLAST.get(), owner, level);
    }

    public void setDamage(float damage) {
        this.damage = damage;
    }

    public void setFormId(int id) {
        this.entityData.set(FORM, id);
    }

    @Override
    protected void defineSynchedData() {
        super.defineSynchedData();
        this.entityData.define(FORM, 0);
    }

    @Override
    protected Item getDefaultItem() {
        return ModItems.KI_BLAST.get();
    }

    @Override
    protected float getGravity() {
        return 0.0F;
    }

    @Override
    public void tick() {
        super.tick();
        if (this.level().isClientSide()) {
            float[] c = Form.byId(this.entityData.get(FORM)).aura;
            this.level().addParticle(new DustParticleOptions(new Vector3f(c[0], c[1], c[2]), 1.5f),
                    getX(), getY(), getZ(), 0, 0, 0);
        } else if (this.tickCount > 100) {
            this.discard();
        }
    }

    @Override
    protected void onHitEntity(EntityHitResult result) {
        super.onHitEntity(result);
        if (!this.level().isClientSide()) {
            Entity owner = getOwner();
            result.getEntity().hurt(this.damageSources().thrown(this, owner), damage);
        }
    }

    @Override
    protected void onHit(HitResult result) {
        super.onHit(result);
        if (!this.level().isClientSide()) {
            this.level().explode(this, getX(), getY(), getZ(), 1.2f, Level.ExplosionInteraction.MOB);
            this.discard();
        }
    }
}
