package com.saiyanlegacy;

import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Abilities;
import net.minecraft.world.entity.player.Player;
import net.minecraftforge.event.AttachCapabilitiesEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.event.entity.living.LivingFallEvent;
import net.minecraftforge.event.entity.living.LivingHurtEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.LogicalSide;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = SaiyanLegacy.MODID)
public class ForgeEvents {

    @SubscribeEvent
    public static void attachCaps(AttachCapabilitiesEvent<Entity> event) {
        if (event.getObject() instanceof Player) {
            event.addCapability(new ResourceLocation(SaiyanLegacy.MODID, "ki"), new KiProvider());
        }
    }

    @SubscribeEvent
    public static void onClone(PlayerEvent.Clone event) {
        event.getOriginal().reviveCaps();
        PlayerKi old = PlayerKi.of(event.getOriginal());
        PlayerKi now = PlayerKi.of(event.getEntity());
        if (old != null && now != null) now.copyFrom(old, event.isWasDeath());
        event.getOriginal().invalidateCaps();
    }

    @SubscribeEvent
    public static void onLogin(PlayerEvent.PlayerLoggedInEvent event) {
        if (event.getEntity() instanceof ServerPlayer p) {
            // Abilities are saved with the player, so make sure flight can't carry over from last session.
            Abilities ab = p.getAbilities();
            if (!p.isCreative() && !p.isSpectator()) {
                ab.mayfly = false;
                ab.flying = false;
                p.onUpdateAbilities();
            }
            PlayerKi k = PlayerKi.of(p);
            if (k != null) KiActions.sync(p, k);
        }
    }

    @SubscribeEvent
    public static void onRespawn(PlayerEvent.PlayerRespawnEvent event) {
        if (event.getEntity() instanceof ServerPlayer p) {
            PlayerKi k = PlayerKi.of(p);
            if (k != null) KiActions.sync(p, k);
        }
    }

    @SubscribeEvent
    public static void onDimension(PlayerEvent.PlayerChangedDimensionEvent event) {
        if (event.getEntity() instanceof ServerPlayer p) {
            PlayerKi k = PlayerKi.of(p);
            if (k != null) KiActions.sync(p, k);
        }
    }

    @SubscribeEvent
    public static void onPlayerTick(TickEvent.PlayerTickEvent event) {
        if (event.phase != TickEvent.Phase.END || event.side != LogicalSide.SERVER) return;
        if (!(event.player instanceof ServerPlayer p)) return;
        PlayerKi k = PlayerKi.of(p);
        if (k != null) KiActions.tick(p, k);
    }

    @SubscribeEvent
    public static void onHurt(LivingHurtEvent event) {
        DamageSource src = event.getSource();

        // Melee damage scales with power level and form.
        if (src.getEntity() instanceof ServerPlayer attacker && src.getDirectEntity() == attacker) {
            PlayerKi k = PlayerKi.of(attacker);
            if (k != null && !k.suppressMult) {
                event.setAmount((float) (event.getAmount() * k.damageMult()));
            }
        }

        // Incoming damage is reduced by power level and form.
        if (event.getEntity() instanceof ServerPlayer victim && !src.is(DamageTypeTags.BYPASSES_INVULNERABILITY)) {
            PlayerKi k = PlayerKi.of(victim);
            if (k != null) {
                event.setAmount((float) (event.getAmount() / k.defenseMult()));
            }
        }
    }

    @SubscribeEvent
    public static void onFall(LivingFallEvent event) {
        if (event.getEntity() instanceof Player p) {
            PlayerKi k = PlayerKi.of(p);
            if (k != null && (k.form != Form.BASE || k.flying)) event.setCanceled(true);
        }
    }

    @SubscribeEvent
    public static void onKill(LivingDeathEvent event) {
        if (event.getSource().getEntity() instanceof ServerPlayer p && event.getEntity() != p) {
            PlayerKi k = PlayerKi.of(p);
            if (k == null) return;
            long gain = (long) (event.getEntity().getMaxHealth() * 2);
            k.power += gain;
            p.displayClientMessage(Component.literal("+" + gain + " Power Level"), true);
            KiActions.sync(p, k);
        }
    }
}
