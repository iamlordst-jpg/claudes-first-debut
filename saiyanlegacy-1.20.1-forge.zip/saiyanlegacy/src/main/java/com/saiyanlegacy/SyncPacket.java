package com.saiyanlegacy;

import java.util.function.Supplier;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.network.NetworkEvent;

public class SyncPacket {
    private final double ki;
    private final double maxKi;
    private final long power;
    private final int form;
    private final boolean flying;
    private final boolean charging;

    public SyncPacket(double ki, double maxKi, long power, int form, boolean flying, boolean charging) {
        this.ki = ki;
        this.maxKi = maxKi;
        this.power = power;
        this.form = form;
        this.flying = flying;
        this.charging = charging;
    }

    public static void encode(SyncPacket m, FriendlyByteBuf buf) {
        buf.writeDouble(m.ki);
        buf.writeDouble(m.maxKi);
        buf.writeLong(m.power);
        buf.writeInt(m.form);
        buf.writeBoolean(m.flying);
        buf.writeBoolean(m.charging);
    }

    public static SyncPacket decode(FriendlyByteBuf buf) {
        return new SyncPacket(buf.readDouble(), buf.readDouble(), buf.readLong(),
                buf.readInt(), buf.readBoolean(), buf.readBoolean());
    }

    public static void handle(SyncPacket m, Supplier<NetworkEvent.Context> ctx) {
        NetworkEvent.Context c = ctx.get();
        c.enqueueWork(() -> ClientKiData.set(m.ki, m.maxKi, m.power, m.form, m.flying, m.charging));
        c.setPacketHandled(true);
    }
}
