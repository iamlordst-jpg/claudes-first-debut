# Saiyan Legacy v2 (Forge 1.20.1, needs GeckoLib 4.4.x)

## Controls (rebindable: Controls > Saiyan Legacy)
C hold: charge ki | Z: ki blast | G hold+release: special move | N: cycle special
X / B: power up / down | K: Kaioken | H hold: guard | R: fly | V: dash / vanish strike / blink
Y: Sparking! (when the meter is full)

## Specials
Kamehameha, Galick Gun (500 PL), Final Flash (5k PL), Spirit Bomb (3k PL), Ki Barrage (200 PL), Solar Flare.

## Forms (Power Level needed)
Super Saiyan 1.5k, SSJ2 6k, SSJ3 15k, SS God 40k, SS Blue 80k, Ultra Instinct 160k (40% auto-dodge).

## Commands (op)
/saiyan power <n>   /saiyan spark
