package com.saiyanlegacy;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.entity.player.Player;

public class PlayerKi {
    // saved
    public double ki = 100;
    public long power = 100;

    // runtime only
    public Form form = Form.BASE;
    public Special special = Special.KAMEHAMEHA;
    public boolean flying;
    public boolean charging;
    public boolean specialCharging;
    public int specialTicks;
    public boolean kaioken;
    public boolean guarding;
    public double sparkMeter;
    public int sparkingTicks;
    public long nextBlastTick;
    public boolean suppressMult;
    public int lastBits = -1;

    public static PlayerKi of(Player p) {
        return p.getCapability(ModCaps.KI).resolve().orElse(null);
    }

    public boolean isSparking() {
        return sparkingTicks > 0;
    }

    public void addSpark(double amount) {
        if (!isSparking()) sparkMeter = Math.min(100.0, sparkMeter + amount);
    }

    public double maxKi() {
        return 100 + 2 * Math.sqrt(power);
    }

    public double damageMult() {
        double m = form.damage * (1 + Math.sqrt(power) / 40.0);
        if (kaioken) m *= 1.5;
        if (isSparking()) m *= 1.5;
        return m;
    }

    public double defenseMult() {
        double m = form.defense * (1 + Math.sqrt(power) / 80.0);
        if (kaioken) m *= 0.8;
        if (isSparking()) m *= 1.3;
        if (guarding) m *= 3.3;
        return m;
    }

    public double speedBonus() {
        return form.speed + (kaioken ? 0.3 : 0.0) + (isSparking() ? 0.2 : 0.0);
    }

    public double drainPerSec() {
        if (isSparking()) return 0.0;
        return form.drain + (kaioken ? 4.0 : 0.0);
    }

    public CompoundTag save() {
        CompoundTag tag = new CompoundTag();
        tag.putDouble("ki", ki);
        tag.putLong("power", power);
        return tag;
    }

    public void load(CompoundTag tag) {
        if (tag.contains("ki")) ki = tag.getDouble("ki");
        if (tag.contains("power")) power = tag.getLong("power");
    }

    public void copyFrom(PlayerKi old, boolean death) {
        power = old.power;
        special = old.special;
        ki = death ? maxKi() : old.ki;
    }
}
