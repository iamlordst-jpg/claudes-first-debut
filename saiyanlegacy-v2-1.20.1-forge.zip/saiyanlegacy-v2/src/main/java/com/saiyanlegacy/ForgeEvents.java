package com.saiyanlegacy;

import com.mojang.brigadier.arguments.LongArgumentType;
import net.minecraft.commands.Commands;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Abilities;
import net.minecraft.world.entity.player.Player;
import net.minecraftforge.event.AttachCapabilitiesEvent;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.living.LivingAttackEvent;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.event.entity.living.LivingFallEvent;
import net.minecraftforge.event.entity.living.LivingHurtEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.LogicalSide;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = SaiyanLegacy.MODID)
public class ForgeEvents {

    @SubscribeEvent
    public static void attachCaps(AttachCapabilitiesEvent<Entity> event) {
        if (event.getObject() instanceof Player) {
            event.addCapability(new ResourceLocation(SaiyanLegacy.MODID, "ki"), new KiProvider());
        }
    }

    @SubscribeEvent
    public static void onClone(PlayerEvent.Clone event) {
        event.getOriginal().reviveCaps();
        PlayerKi old = PlayerKi.of(event.getOriginal());
        PlayerKi now = PlayerKi.of(event.getEntity());
        if (old != null && now != null) now.copyFrom(old, event.isWasDeath());
        event.getOriginal().invalidateCaps();
    }

    @SubscribeEvent
    public static void onLogin(PlayerEvent.PlayerLoggedInEvent event) {
        if (event.getEntity() instanceof ServerPlayer p) {
            // Abilities are saved with the player, so make sure flight can't carry over from the last session.
            Abilities ab = p.getAbilities();
            if (!p.isCreative() && !p.isSpectator()) {
                ab.mayfly = false;
                ab.flying = false;
                p.onUpdateAbilities();
            }
            PlayerKi k = PlayerKi.of(p);
            if (k != null) {
                KiActions.sync(p, k);
                KiActions.broadcastState(p, k);
            }
        }
    }

    @SubscribeEvent
    public static void onRespawn(PlayerEvent.PlayerRespawnEvent event) {
        if (event.getEntity() instanceof ServerPlayer p) {
            PlayerKi k = PlayerKi.of(p);
            if (k != null) {
                KiActions.sync(p, k);
                KiActions.broadcastState(p, k);
            }
        }
    }

    @SubscribeEvent
    public static void onDimension(PlayerEvent.PlayerChangedDimensionEvent event) {
        if (event.getEntity() instanceof ServerPlayer p) {
            PlayerKi k = PlayerKi.of(p);
            if (k != null) {
                KiActions.sync(p, k);
                KiActions.broadcastState(p, k);
            }
        }
    }

    /** When a player starts tracking another player, send that player's current aura/pose state. */
    @SubscribeEvent
    public static void onStartTracking(PlayerEvent.StartTracking event) {
        if (event.getTarget() instanceof ServerPlayer target && event.getEntity() instanceof ServerPlayer viewer) {
            PlayerKi k = PlayerKi.of(target);
            if (k != null) ModNetwork.toPlayer(viewer, new StatePacket(target.getId(), KiActions.bits(k)));
        }
    }

    @SubscribeEvent
    public static void onPlayerTick(TickEvent.PlayerTickEvent event) {
        if (event.phase != TickEvent.Phase.END || event.side != LogicalSide.SERVER) return;
        if (!(event.player instanceof ServerPlayer p)) return;
        PlayerKi k = PlayerKi.of(p);
        if (k != null) KiActions.tick(p, k);
    }

    /** Ultra Instinct: automatically dodges a share of incoming attacks. */
    @SubscribeEvent
    public static void onAttack(LivingAttackEvent event) {
        if (!(event.getEntity() instanceof ServerPlayer v)) return;
        DamageSource src = event.getSource();
        if (src.is(DamageTypeTags.BYPASSES_INVULNERABILITY)) return;
        if (src.getEntity() == null && src.getDirectEntity() == null) return;
        PlayerKi k = PlayerKi.of(v);
        if (k == null || k.form != Form.ULTRA_INSTINCT) return;
        if (v.getRandom().nextFloat() < 0.4f) {
            event.setCanceled(true);
            v.serverLevel().sendParticles(ParticleTypes.CLOUD, v.getX(), v.getY() + 1.0, v.getZ(), 15, 0.4, 0.6, 0.4, 0.1);
            v.serverLevel().playSound(null, v.blockPosition(), SoundEvents.ENDERMAN_TELEPORT, SoundSource.PLAYERS, 0.8f, 2.0f);
            k.addSpark(2);
        }
    }

    @SubscribeEvent
    public static void onHurt(LivingHurtEvent event) {
        DamageSource src = event.getSource();

        // Melee damage scales with power level, form, Kaioken and Sparking mode.
        if (src.getEntity() instanceof ServerPlayer attacker && src.getDirectEntity() == attacker) {
            PlayerKi k = PlayerKi.of(attacker);
            if (k != null && !k.suppressMult) {
                event.setAmount((float) (event.getAmount() * k.damageMult()));
                k.addSpark(3);
            }
        }

        // Incoming damage is reduced by power level, form and Guard.
        if (event.getEntity() instanceof ServerPlayer victim && !src.is(DamageTypeTags.BYPASSES_INVULNERABILITY)) {
            PlayerKi k = PlayerKi.of(victim);
            if (k != null) {
                event.setAmount((float) (event.getAmount() / k.defenseMult()));
                k.addSpark(2);
                if (k.guarding) {
                    k.ki = Math.max(0, k.ki - event.getAmount() * 0.5);
                    if (k.ki <= 0) {
                        k.guarding = false;
                        KiActions.msg(victim, "Guard broken!");
                    }
                }
            }
        }
    }

    @SubscribeEvent
    public static void onFall(LivingFallEvent event) {
        if (event.getEntity() instanceof Player p) {
            PlayerKi k = PlayerKi.of(p);
            if (k != null && (k.form != Form.BASE || k.flying)) event.setCanceled(true);
        }
    }

    @SubscribeEvent
    public static void onKill(LivingDeathEvent event) {
        if (event.getSource().getEntity() instanceof ServerPlayer p && event.getEntity() != p) {
            PlayerKi k = PlayerKi.of(p);
            if (k == null) return;
            long gain = (long) (event.getEntity().getMaxHealth() * 4);
            if (event.getEntity() instanceof Saibaman) gain += 150;
            k.power += gain;
            k.addSpark(10);
            p.displayClientMessage(Component.literal("+" + gain + " Power Level"), true);
            KiActions.sync(p, k);
        }
    }

    @SubscribeEvent
    public static void onCommands(RegisterCommandsEvent event) {
        event.getDispatcher().register(Commands.literal("saiyan")
                .requires(s -> s.hasPermission(2))
                .then(Commands.literal("power")
                        .then(Commands.argument("amount", LongArgumentType.longArg(0))
                                .executes(ctx -> {
                                    ServerPlayer p = ctx.getSource().getPlayerOrException();
                                    PlayerKi k = PlayerKi.of(p);
                                    if (k != null) {
                                        k.power = LongArgumentType.getLong(ctx, "amount");
                                        k.ki = k.maxKi();
                                        KiActions.sync(p, k);
                                    }
                                    ctx.getSource().sendSuccess(() -> Component.literal("Power level updated."), false);
                                    return 1;
                                })))
                .then(Commands.literal("spark")
                        .executes(ctx -> {
                            ServerPlayer p = ctx.getSource().getPlayerOrException();
                            PlayerKi k = PlayerKi.of(p);
                            if (k != null) {
                                k.sparkMeter = 100;
                                KiActions.sync(p, k);
                            }
                            ctx.getSource().sendSuccess(() -> Component.literal("Sparking meter filled."), false);
                            return 1;
                        })));
    }
}
