package com.saiyanlegacy;

import java.util.List;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LightningBolt;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;
import net.minecraftforge.registries.RegistryObject;

public class DragonBallItem extends Item {
    public final int stars;

    public DragonBallItem(int stars, Properties props) {
        super(props);
        this.stars = stars;
    }

    private static ItemStack find(Player p, Item item) {
        for (ItemStack s : p.getInventory().items) if (s.is(item)) return s;
        for (ItemStack s : p.getInventory().offhand) if (s.is(item)) return s;
        return ItemStack.EMPTY;
    }

    private static boolean hasAll(Player p) {
        for (RegistryObject<Item> ball : ModItems.DRAGON_BALLS) {
            if (find(p, ball.get()).isEmpty()) return false;
        }
        return true;
    }

    public static boolean carries(Player p) {
        for (RegistryObject<Item> ball : ModItems.DRAGON_BALLS) {
            if (!find(p, ball.get()).isEmpty()) return true;
        }
        return false;
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack held = player.getItemInHand(hand);
        if (!hasAll(player)) {
            if (!level.isClientSide() && player instanceof ServerPlayer sp) {
                KiActions.msg(sp, "You need all 7 Dragon Balls to summon Shenron.");
            }
            return InteractionResultHolder.fail(held);
        }
        if (level.isClientSide()) return InteractionResultHolder.success(held);

        if (player instanceof ServerPlayer sp) {
            for (RegistryObject<Item> ball : ModItems.DRAGON_BALLS) {
                ItemStack s = find(sp, ball.get());
                if (!s.isEmpty()) s.shrink(1);
            }
            LightningBolt bolt = EntityType.LIGHTNING_BOLT.create(level);
            if (bolt != null) {
                bolt.moveTo(sp.position());
                bolt.setVisualOnly(true);
                level.addFreshEntity(bolt);
            }
            level.playSound(null, sp.blockPosition(), SoundEvents.ENDER_DRAGON_GROWL, SoundSource.PLAYERS, 1.0f, 0.8f);
            sp.sendSystemMessage(Component.literal("The Eternal Dragon Shenron has been summoned!").withStyle(ChatFormatting.GOLD));

            if (sp.isShiftKeyDown()) {
                sp.getInventory().add(new ItemStack(ModItems.SENZU_BEAN.get(), 10));
                sp.sendSystemMessage(Component.literal("Your wish is granted: 10 Senzu Beans.").withStyle(ChatFormatting.GREEN));
            } else {
                PlayerKi k = PlayerKi.of(sp);
                if (k != null) {
                    k.power += 25000;
                    k.ki = k.maxKi();
                    KiActions.sync(sp, k);
                }
                sp.sendSystemMessage(Component.literal("Your wish is granted: +25000 Power Level.").withStyle(ChatFormatting.AQUA));
            }
        }
        return InteractionResultHolder.consume(held);
    }

    @Override
    public void appendHoverText(ItemStack stack, Level level, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.literal("Collect all 7, then right-click to summon Shenron."));
        tooltip.add(Component.literal("Wish: +25000 Power Level  (sneak: 10 Senzu Beans)"));
    }
}
