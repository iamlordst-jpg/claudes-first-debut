package com.saiyanlegacy;

import java.util.function.Supplier;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.network.NetworkEvent;

public class SyncPacket {
    private final double ki;
    private final double maxKi;
    private final long power;
    private final float spark;
    private final int sparkingTicks;
    private final int special;
    private final int bits;

    public SyncPacket(double ki, double maxKi, long power, float spark, int sparkingTicks, int special, int bits) {
        this.ki = ki;
        this.maxKi = maxKi;
        this.power = power;
        this.spark = spark;
        this.sparkingTicks = sparkingTicks;
        this.special = special;
        this.bits = bits;
    }

    public static void encode(SyncPacket m, FriendlyByteBuf buf) {
        buf.writeDouble(m.ki);
        buf.writeDouble(m.maxKi);
        buf.writeLong(m.power);
        buf.writeFloat(m.spark);
        buf.writeInt(m.sparkingTicks);
        buf.writeInt(m.special);
        buf.writeInt(m.bits);
    }

    public static SyncPacket decode(FriendlyByteBuf buf) {
        return new SyncPacket(buf.readDouble(), buf.readDouble(), buf.readLong(), buf.readFloat(),
                buf.readInt(), buf.readInt(), buf.readInt());
    }

    public static void handle(SyncPacket m, Supplier<NetworkEvent.Context> ctx) {
        NetworkEvent.Context c = ctx.get();
        c.enqueueWork(() -> ClientKiData.set(m.ki, m.maxKi, m.power, m.spark, m.sparkingTicks, m.special, m.bits));
        c.setPacketHandled(true);
    }
}
