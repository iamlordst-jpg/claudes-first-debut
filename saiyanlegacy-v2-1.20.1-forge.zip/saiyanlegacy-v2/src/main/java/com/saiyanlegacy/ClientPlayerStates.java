package com.saiyanlegacy;

import java.util.HashMap;
import java.util.Map;

/** Client-side map of entityId -> state bits, used by the aura/hair layers and flight pose. */
public class ClientPlayerStates {
    public static final int FLYING = 1;
    public static final int CHARGING = 2;
    public static final int SPECIAL = 4;
    public static final int KAIOKEN = 8;
    public static final int SPARKING = 16;
    public static final int GUARD = 32;

    private static final Map<Integer, Integer> BITS = new HashMap<>();

    public static void set(int entityId, int bits) {
        BITS.put(entityId, bits);
    }

    public static int get(int entityId) {
        return BITS.getOrDefault(entityId, 0);
    }

    public static void clear() {
        BITS.clear();
    }
}
