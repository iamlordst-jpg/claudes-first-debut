package com.saiyanlegacy;

import java.util.UUID;
import net.minecraft.commands.arguments.EntityAnchorArgument;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LightningBolt;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.player.Abilities;
import net.minecraft.world.entity.projectile.ProjectileUtil;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import org.joml.Vector3f;

public final class KiActions {
    private static final UUID SPEED_UUID = UUID.fromString("5f1a7c1e-3b0d-4e7a-9a53-2c6f0d9e4b11");
    private static final float[] RED = {1.0f, 0.12f, 0.08f};
    private static final float[] GOLD = {1.0f, 0.85f, 0.2f};
    private static final float[] WHITE = {1.0f, 1.0f, 1.0f};

    private KiActions() {}

    // ------------------------------------------------------------------ helpers

    public static void msg(ServerPlayer p, String text) {
        p.displayClientMessage(Component.literal(text), true);
    }

    public static int bits(PlayerKi k) {
        int b = 0;
        if (k.flying) b |= ClientPlayerStates.FLYING;
        if (k.charging) b |= ClientPlayerStates.CHARGING;
        if (k.specialCharging) b |= ClientPlayerStates.SPECIAL;
        if (k.kaioken) b |= ClientPlayerStates.KAIOKEN;
        if (k.isSparking()) b |= ClientPlayerStates.SPARKING;
        if (k.guarding) b |= ClientPlayerStates.GUARD;
        return b | (k.form.ordinal() << 8);
    }

    public static void sync(ServerPlayer p, PlayerKi k) {
        ModNetwork.toPlayer(p, new SyncPacket(k.ki, k.maxKi(), k.power, (float) k.sparkMeter,
                k.sparkingTicks, k.special.ordinal(), bits(k)));
    }

    public static void broadcastState(ServerPlayer p, PlayerKi k) {
        int b = bits(k);
        k.lastBits = b;
        ModNetwork.toTracking(p, new StatePacket(p.getId(), b));
    }

    public static void fx(ServerPlayer p, int type, float amount) {
        ModNetwork.toPlayer(p, new FxPacket(type, amount));
    }

    public static void shakeNear(ServerLevel lvl, Vec3 pos, double radius, float amount) {
        for (ServerPlayer sp : lvl.players()) {
            double d = sp.position().distanceTo(pos);
            if (d < radius) fx(sp, 0, amount * (float) (1.0 - d / radius));
        }
    }

    private static void aura(ServerLevel lvl, ServerPlayer p, float[] c, int count, float scale) {
        DustParticleOptions opt = new DustParticleOptions(new Vector3f(c[0], c[1], c[2]), scale);
        for (int i = 0; i < count; i++) {
            double x = p.getX() + (p.getRandom().nextDouble() - 0.5) * 1.2;
            double y = p.getY() + p.getRandom().nextDouble() * 2.0;
            double z = p.getZ() + (p.getRandom().nextDouble() - 0.5) * 1.2;
            lvl.sendParticles(opt, x, y, z, 1, 0, 0.1, 0, 0.02);
        }
    }

    private static void lightning(ServerLevel lvl, ServerPlayer p) {
        LightningBolt bolt = EntityType.LIGHTNING_BOLT.create(lvl);
        if (bolt != null) {
            bolt.moveTo(p.position());
            bolt.setVisualOnly(true);
            lvl.addFreshEntity(bolt);
        }
    }

    // ------------------------------------------------------------------ dispatch

    public static void perform(ServerPlayer p, ActionPacket.Action action) {
        PlayerKi k = PlayerKi.of(p);
        if (k == null) return;
        switch (action) {
            case CHARGE_START -> k.charging = true;
            case CHARGE_STOP -> k.charging = false;
            case BLAST -> blast(p, k);
            case SPECIAL_START -> startSpecial(p, k);
            case SPECIAL_RELEASE -> {
                if (k.specialCharging) releaseSpecial(p, k);
                k.specialCharging = false;
                k.specialTicks = 0;
            }
            case CYCLE_SPECIAL -> {
                k.special = k.special.next();
                msg(p, "Special: " + k.special.displayName);
            }
            case TRANSFORM_UP -> transform(p, k, 1);
            case TRANSFORM_DOWN -> transform(p, k, -1);
            case TOGGLE_FLY -> toggleFly(p, k);
            case DASH -> dash(p, k);
            case GUARD_START -> {
                if (k.ki >= 5) k.guarding = true;
            }
            case GUARD_STOP -> k.guarding = false;
            case KAIOKEN -> toggleKaioken(p, k);
            case SPARKING -> sparking(p, k);
        }
        sync(p, k);
        broadcastState(p, k);
    }

    // ------------------------------------------------------------------ per-tick

    public static void tick(ServerPlayer p, PlayerKi k) {
        ServerLevel lvl = p.serverLevel();
        boolean sparking = k.isSparking();

        double regen = (k.charging ? 0.6 : 0.04) * (sparking ? 3.0 : 1.0);
        k.ki = Math.min(k.maxKi(), k.ki + regen);

        if (sparking) {
            k.sparkingTicks--;
            if (p.tickCount % 2 == 0) aura(lvl, p, p.tickCount % 4 == 0 ? GOLD : WHITE, 4, 1.6f);
            if (k.sparkingTicks <= 0) {
                k.sparkingTicks = 0;
                applySpeed(p, k);
                if (k.flying) applyFlight(p, k);
                msg(p, "Sparking mode ended.");
            }
        }

        if (k.charging) {
            if (p.tickCount % 20 == 0) k.power += 5; // training: charging slowly raises power level
            if (p.tickCount % 2 == 0) {
                aura(lvl, p, k.form.aura, 4, 1.2f);
                lvl.sendParticles(ParticleTypes.ELECTRIC_SPARK, p.getX(), p.getY() + 1.0, p.getZ(), 2, 0.5, 0.8, 0.5, 0.05);
            }
        }

        if (k.form != Form.BASE || k.kaioken) {
            k.ki -= k.drainPerSec() / 20.0;
            if (p.tickCount % 3 == 0) aura(lvl, p, k.kaioken ? RED : k.form.aura, 3, 1.4f);
            if (k.ki <= 0) {
                k.ki = 0;
                k.kaioken = false;
                setForm(p, k, Form.BASE);
                msg(p, "You ran out of ki and powered down.");
            }
        }

        if (k.guarding) {
            k.ki -= 0.05;
            if (k.ki <= 0) {
                k.ki = 0;
                k.guarding = false;
                msg(p, "Guard broken!");
            } else if (p.tickCount % 4 == 0) {
                DustParticleOptions shield = new DustParticleOptions(new Vector3f(0.4f, 0.8f, 1.0f), 1.0f);
                for (int i = 0; i < 8; i++) {
                    double a = i * Math.PI / 4.0 + p.tickCount * 0.2;
                    lvl.sendParticles(shield, p.getX() + Math.cos(a) * 1.1, p.getY() + 0.3 + (i % 4) * 0.45,
                            p.getZ() + Math.sin(a) * 1.1, 1, 0, 0, 0, 0);
                }
            }
        }

        if (k.flying) {
            if (!sparking) k.ki -= 0.08;
            p.fallDistance = 0;
            if (k.ki <= 0) {
                k.ki = 0;
                setFlying(p, k, false);
                msg(p, "Out of ki - you can no longer fly.");
            }
        }

        if (k.specialCharging) {
            if (k.ki < 20) {
                k.specialCharging = false;
                k.specialTicks = 0;
                msg(p, k.special.displayName + " cancelled - out of ki.");
            } else {
                k.specialTicks = Math.min(k.special.maxTicks(), k.specialTicks + 1);
                chargeFx(lvl, p, k);
            }
        }

        int b = bits(k);
        if (b != k.lastBits || p.tickCount % 40 == 0) broadcastState(p, k);
        if (p.tickCount % 5 == 0) sync(p, k);
    }

    private static void chargeFx(ServerLevel lvl, ServerPlayer p, PlayerKi k) {
        float[] c = k.special.color;
        Vec3 pos;
        float size;
        if (k.special.type == Special.Type.BOMB) {
            pos = p.position().add(0, 3.4 + k.specialTicks / 80.0, 0);
            size = Mth.clamp(1.0f + k.specialTicks / 50.0f, 1.0f, 4.0f);
        } else {
            pos = p.getEyePosition().add(p.getLookAngle().scale(1.6)).add(0, -0.5, 0);
            size = Mth.clamp(0.8f + k.specialTicks / 25.0f, 0.8f, 4.0f);
        }
        lvl.sendParticles(new DustParticleOptions(new Vector3f(c[0], c[1], c[2]), size),
                pos.x, pos.y, pos.z, 3, 0.15, 0.15, 0.15, 0);
        if (k.specialTicks % 4 == 0) {
            lvl.sendParticles(ParticleTypes.ELECTRIC_SPARK, pos.x, pos.y, pos.z, 3, 0.4, 0.4, 0.4, 0.1);
        }
    }

    // ------------------------------------------------------------------ ki blast

    private static void blast(ServerPlayer p, PlayerKi k) {
        if (p.tickCount < k.nextBlastTick) return;
        if (k.ki < 4) {
            msg(p, "Not enough ki.");
            return;
        }
        k.ki -= 4;
        k.nextBlastTick = p.tickCount + 8;
        spawnBlast(p, k, 5.0, 0.0f);
        p.level().playSound(null, p.blockPosition(), SoundEvents.FIRECHARGE_USE, SoundSource.PLAYERS, 0.8f, 1.6f);
    }

    private static void spawnBlast(ServerPlayer p, PlayerKi k, double baseDamage, float inaccuracy) {
        KiBlastEntity blast = new KiBlastEntity(p.level(), p);
        blast.setDamage((float) (baseDamage * k.damageMult()));
        blast.setFormId(k.form.ordinal());
        blast.shootFromRotation(p, p.getXRot(), p.getYRot(), 0.0F, 2.5F, inaccuracy);
        p.level().addFreshEntity(blast);
    }

    // ------------------------------------------------------------------ specials

    private static void startSpecial(ServerPlayer p, PlayerKi k) {
        Special s = k.special;
        if (k.power < s.minPower) {
            msg(p, s.displayName + " needs " + String.format("%,d", s.minPower) + " Power Level.");
            return;
        }
        if (s.type == Special.Type.FLARE) {
            solarFlare(p, k);
            return;
        }
        if (k.ki < 25) {
            msg(p, "Not enough ki for " + s.displayName + ".");
            return;
        }
        k.specialCharging = true;
        k.specialTicks = 0;
    }

    private static void releaseSpecial(ServerPlayer p, PlayerKi k) {
        switch (k.special.type) {
            case BEAM -> fireBeam(p, k);
            case BOMB -> fireBomb(p, k);
            case BARRAGE -> fireBarrage(p, k);
            default -> { }
        }
    }

    private static double distToSegment(Vec3 pt, Vec3 a, Vec3 b) {
        Vec3 ab = b.subtract(a);
        double lenSqr = ab.lengthSqr();
        if (lenSqr < 1.0E-4) return pt.distanceTo(a);
        double t = Mth.clamp(pt.subtract(a).dot(ab) / lenSqr, 0.0, 1.0);
        return pt.distanceTo(a.add(ab.scale(t)));
    }

    private static void damageNear(ServerPlayer p, PlayerKi k, ServerLevel lvl, AABB box, java.util.function.Predicate<LivingEntity> filter, float dmg, Vec3 push) {
        k.suppressMult = true;
        try {
            for (LivingEntity e : lvl.getEntitiesOfClass(LivingEntity.class, box, x -> x != p && x.isAlive())) {
                if (!filter.test(e)) continue;
                e.hurt(p.damageSources().indirectMagic(p, p), dmg);
                if (push != null) {
                    e.push(push.x, push.y, push.z);
                    e.hurtMarked = true;
                }
                k.addSpark(4);
            }
        } finally {
            k.suppressMult = false;
        }
    }

    private static void fireBeam(ServerPlayer p, PlayerKi k) {
        Special s = k.special;
        double costMult = s == Special.FINAL_FLASH ? 1.5 : 1.0;
        int ticks = k.specialTicks;
        double cost = (20 + ticks * 0.5) * costMult;
        if (k.ki < cost) {
            ticks = (int) ((k.ki / costMult - 20) / 0.5);
            cost = (20 + ticks * 0.5) * costMult;
        }
        if (ticks < 10) {
            msg(p, s.displayName + " fizzled - hold the key longer!");
            return;
        }
        k.ki -= cost;
        double power = ticks / 100.0;

        ServerLevel lvl = p.serverLevel();
        Vec3 dir = p.getLookAngle();
        Vec3 start = p.getEyePosition().add(dir.scale(1.0)).add(0, -0.3, 0);
        double range = (30 + 60 * power) * s.rangeFactor;
        Vec3 end = start.add(dir.scale(range));
        BlockHitResult hit = lvl.clip(new ClipContext(start, end, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, p));
        boolean hitBlock = hit.getType() != HitResult.Type.MISS;
        Vec3 realEnd = hitBlock ? hit.getLocation() : end;
        double len = start.distanceTo(realEnd);

        float[] c = s.color;
        DustParticleOptions core = new DustParticleOptions(new Vector3f(c[0], c[1], c[2]),
                (float) Mth.clamp((1.5 + 2 * power) * s.widthFactor, 0.5, 4.0));
        DustParticleOptions white = new DustParticleOptions(new Vector3f(1.0f, 1.0f, 1.0f), 1.2f);
        for (double d = 0; d <= len; d += 0.6) {
            Vec3 pt = start.add(dir.scale(d));
            lvl.sendParticles(core, pt.x, pt.y, pt.z, 2, 0.2, 0.2, 0.2, 0);
            lvl.sendParticles(white, pt.x, pt.y, pt.z, 1, 0.05, 0.05, 0.05, 0);
        }

        float dmg = (float) ((12 + 38 * power) * k.damageMult() * s.damageFactor);
        double radius = (1.5 + 2 * power) * s.widthFactor;
        AABB box = new AABB(start, realEnd).inflate(radius + 1);
        final Vec3 fStart = start;
        final Vec3 fEnd = realEnd;
        damageNear(p, k, lvl, box, e -> distToSegment(e.getBoundingBox().getCenter(), fStart, fEnd) <= radius,
                dmg, new Vec3(dir.x * 1.2, 0.35, dir.z * 1.2));

        if (hitBlock && len > 4.0) {
            lvl.explode(p, realEnd.x, realEnd.y, realEnd.z, (float) ((2.0 + 4.0 * power) * Math.min(1.5, s.widthFactor)),
                    Level.ExplosionInteraction.MOB);
        }
        lvl.playSound(null, p.blockPosition(), SoundEvents.BEACON_ACTIVATE, SoundSource.PLAYERS, 1.5f, 0.6f);
        lvl.playSound(null, p.blockPosition(), SoundEvents.GENERIC_EXPLODE, SoundSource.PLAYERS, 0.8f, 1.4f);
        shakeNear(lvl, p.position(), 40, (float) (0.8 + 1.2 * power));
        fx(p, 2, 8.0f);
        if (s == Special.FINAL_FLASH) fx(p, 1, 0.4f);
        k.addSpark(6);
    }

    private static void fireBomb(ServerPlayer p, PlayerKi k) {
        int ticks = k.specialTicks;
        double cost = 30 + ticks * 0.5;
        if (k.ki < cost) {
            ticks = (int) ((k.ki - 30) / 0.5);
            cost = 30 + ticks * 0.5;
        }
        if (ticks < 40) {
            msg(p, "Spirit Bomb fizzled - it needs more time to gather energy!");
            return;
        }
        k.ki -= cost;
        double power = ticks / 200.0;

        ServerLevel lvl = p.serverLevel();
        Vec3 eye = p.getEyePosition();
        Vec3 look = p.getLookAngle();
        Vec3 far = eye.add(look.scale(70));
        BlockHitResult hit = lvl.clip(new ClipContext(eye, far, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, p));
        Vec3 target = hit.getType() != HitResult.Type.MISS ? hit.getLocation() : far;

        double radius = 6 + 8 * power;
        float dmg = (float) ((60 + 140 * power) * k.damageMult());

        float[] c = k.special.color;
        DustParticleOptions big = new DustParticleOptions(new Vector3f(c[0], c[1], c[2]), 4.0f);
        for (int y = 0; y < 30; y++) {
            lvl.sendParticles(big, target.x, target.y + y, target.z, 6, radius * 0.12, 0.0, radius * 0.12, 0);
        }
        lvl.sendParticles(ParticleTypes.EXPLOSION_EMITTER, target.x, target.y + 1, target.z, 3, radius * 0.3, 1, radius * 0.3, 0);

        AABB box = new AABB(target, target).inflate(radius);
        final Vec3 fTarget = target;
        damageNear(p, k, lvl, box, e -> e.position().distanceTo(fTarget) <= radius, dmg, new Vec3(0, 0.8, 0));
        lvl.explode(p, target.x, target.y, target.z, (float) Math.min(10.0, 4.0 + 6.0 * power), Level.ExplosionInteraction.MOB);
        lvl.playSound(null, p.blockPosition(), SoundEvents.LIGHTNING_BOLT_THUNDER, SoundSource.PLAYERS, 2.0f, 0.6f);
        shakeNear(lvl, target, 70, (float) (1.0 + 1.5 * power));
        for (ServerPlayer sp : lvl.players()) {
            if (sp.position().distanceTo(target) < 40) fx(sp, 1, 0.6f);
        }
        k.addSpark(10);
    }

    private static void fireBarrage(ServerPlayer p, PlayerKi k) {
        int n = Math.min(16, k.specialTicks / 4);
        double cost = 10 + n * 2.5;
        if (k.ki < cost) {
            n = (int) ((k.ki - 10) / 2.5);
            cost = 10 + n * 2.5;
        }
        if (n < 3) {
            msg(p, "Ki Barrage fizzled - hold the key longer!");
            return;
        }
        k.ki -= cost;
        for (int i = 0; i < n; i++) spawnBlast(p, k, 3.0, 10.0f);
        p.level().playSound(null, p.blockPosition(), SoundEvents.FIRECHARGE_USE, SoundSource.PLAYERS, 1.2f, 1.0f);
        fx(p, 0, 0.5f);
        k.addSpark(4);
    }

    private static void solarFlare(ServerPlayer p, PlayerKi k) {
        if (k.ki < 20) {
            msg(p, "Not enough ki for Solar Flare.");
            return;
        }
        k.ki -= 20;
        ServerLevel lvl = p.serverLevel();
        lvl.sendParticles(ParticleTypes.FLASH, p.getX(), p.getEyeY(), p.getZ(), 3, 0.3, 0.3, 0.3, 0);
        for (LivingEntity e : lvl.getEntitiesOfClass(LivingEntity.class, p.getBoundingBox().inflate(14), x -> x != p)) {
            e.addEffect(new MobEffectInstance(MobEffects.BLINDNESS, 200, 0));
            e.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 200, 3));
        }
        for (ServerPlayer sp : lvl.players()) {
            if (sp != p && sp.position().distanceTo(p.position()) < 24) fx(sp, 1, 1.0f);
        }
        lvl.playSound(null, p.blockPosition(), SoundEvents.FIREWORK_ROCKET_LARGE_BLAST, SoundSource.PLAYERS, 1.5f, 1.4f);
        msg(p, "Solar Flare!");
    }

    // ------------------------------------------------------------------ forms

    private static void transform(ServerPlayer p, PlayerKi k, int dir) {
        Form[] all = Form.values();
        int idx = k.form.ordinal() + dir;
        if (idx < 0) {
            msg(p, "Already in base form.");
            return;
        }
        if (idx >= all.length) {
            msg(p, "You have reached your highest form.");
            return;
        }
        Form target = all[idx];
        if (dir > 0) {
            if (k.power < target.minPower) {
                msg(p, target.displayName + " needs " + String.format("%,d", target.minPower) + " Power Level.");
                return;
            }
            if (k.ki < 25) {
                msg(p, "Not enough ki to transform.");
                return;
            }
            k.ki -= 10;
        }
        setForm(p, k, target);
        msg(p, target.displayName);
    }

    public static void setForm(ServerPlayer p, PlayerKi k, Form f) {
        boolean up = f.ordinal() > k.form.ordinal();
        k.form = f;
        applySpeed(p, k);
        if (k.flying) applyFlight(p, k);
        ServerLevel lvl = p.serverLevel();
        aura(lvl, p, f.aura, 40, 1.8f);
        lvl.sendParticles(ParticleTypes.FLASH, p.getX(), p.getY() + 1.0, p.getZ(), 1, 0, 0, 0, 0);
        if (up && f.ordinal() >= Form.SUPER_SAIYAN.ordinal()) lightning(lvl, p);
        lvl.playSound(null, p.blockPosition(), SoundEvents.BEACON_POWER_SELECT, SoundSource.PLAYERS, 1.2f, 0.7f);
        if (up) {
            shakeNear(lvl, p.position(), 30, 1.4f);
            fx(p, 1, 0.7f);
            fx(p, 2, 10.0f);
        }
    }

    private static void toggleKaioken(ServerPlayer p, PlayerKi k) {
        if (k.kaioken) {
            k.kaioken = false;
            msg(p, "Kaioken off.");
        } else if (k.ki < 20) {
            msg(p, "Not enough ki for Kaioken.");
            return;
        } else {
            k.kaioken = true;
            aura(p.serverLevel(), p, RED, 40, 1.8f);
            p.serverLevel().playSound(null, p.blockPosition(), SoundEvents.BLAZE_SHOOT, SoundSource.PLAYERS, 1.2f, 0.6f);
            fx(p, 0, 0.8f);
            msg(p, "Kaioken!");
        }
        applySpeed(p, k);
        if (k.flying) applyFlight(p, k);
    }

    private static void sparking(ServerPlayer p, PlayerKi k) {
        if (k.isSparking()) return;
        if (k.sparkMeter < 100) {
            msg(p, "Sparking meter " + (int) k.sparkMeter + "% - land and take hits to fill it.");
            return;
        }
        k.sparkMeter = 0;
        k.sparkingTicks = 600;
        k.ki = k.maxKi();
        applySpeed(p, k);
        if (k.flying) applyFlight(p, k);
        ServerLevel lvl = p.serverLevel();
        aura(lvl, p, GOLD, 60, 2.0f);
        lvl.sendParticles(ParticleTypes.FLASH, p.getX(), p.getY() + 1.0, p.getZ(), 1, 0, 0, 0, 0);
        lightning(lvl, p);
        lvl.playSound(null, p.blockPosition(), SoundEvents.BEACON_ACTIVATE, SoundSource.PLAYERS, 1.5f, 1.2f);
        shakeNear(lvl, p.position(), 40, 1.6f);
        fx(p, 1, 0.8f);
        fx(p, 2, 14.0f);
        msg(p, "SPARKING!");
    }

    public static void applySpeed(ServerPlayer p, PlayerKi k) {
        AttributeInstance speed = p.getAttribute(Attributes.MOVEMENT_SPEED);
        if (speed == null) return;
        speed.removeModifier(SPEED_UUID);
        double bonus = k.speedBonus();
        if (bonus > 0) {
            speed.addTransientModifier(new AttributeModifier(SPEED_UUID, "saiyanlegacy.form",
                    bonus, AttributeModifier.Operation.MULTIPLY_TOTAL));
        }
    }

    // ------------------------------------------------------------------ flight

    private static void toggleFly(ServerPlayer p, PlayerKi k) {
        if (k.flying) {
            setFlying(p, k, false);
        } else if (k.ki < 10) {
            msg(p, "Not enough ki to fly.");
        } else {
            setFlying(p, k, true);
        }
    }

    public static void setFlying(ServerPlayer p, PlayerKi k, boolean on) {
        k.flying = on;
        applyFlight(p, k);
    }

    private static void applyFlight(ServerPlayer p, PlayerKi k) {
        Abilities ab = p.getAbilities();
        if (k.flying) {
            ab.mayfly = true;
            ab.flying = true;
            ab.setFlyingSpeed(0.06f + (float) k.speedBonus() * 0.05f);
        } else {
            if (!p.isCreative() && !p.isSpectator()) {
                ab.mayfly = false;
                ab.flying = false;
            }
            ab.setFlyingSpeed(0.05f);
        }
        p.onUpdateAbilities();
    }

    // ------------------------------------------------------------------ dash / vanish strike / blink

    private static void dash(ServerPlayer p, PlayerKi k) {
        ServerLevel lvl = p.serverLevel();
        Vec3 eye = p.getEyePosition();
        Vec3 dir = p.getLookAngle();
        Vec3 end = eye.add(dir.scale(24));

        // Vanish Strike: look at a creature within 24 blocks to teleport behind it and hit it.
        AABB search = p.getBoundingBox().expandTowards(dir.scale(24)).inflate(1.5);
        EntityHitResult ehr = ProjectileUtil.getEntityHitResult(lvl, p, eye, end, search,
                e -> e instanceof LivingEntity && e.isAlive() && e != p && !e.isSpectator());
        if (ehr != null) {
            BlockHitResult wall = lvl.clip(new ClipContext(eye, ehr.getLocation(), ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, p));
            if (wall.getType() == HitResult.Type.MISS) {
                vanishStrike(p, k, (LivingEntity) ehr.getEntity());
                return;
            }
        }

        if (k.flying) {
            if (k.ki < 8) {
                msg(p, "Not enough ki to dash.");
                return;
            }
            k.ki -= 8;
            p.setDeltaMovement(dir.scale(2.4));
            p.hurtMarked = true;
            lvl.sendParticles(ParticleTypes.CLOUD, p.getX(), p.getY() + 1.0, p.getZ(), 25, 0.4, 0.6, 0.4, 0.1);
            lvl.playSound(null, p.blockPosition(), SoundEvents.FIREWORK_ROCKET_LAUNCH, SoundSource.PLAYERS, 1.0f, 1.2f);
            fx(p, 2, 8.0f);
        } else {
            blink(p, k);
        }
    }

    private static void vanishStrike(ServerPlayer p, PlayerKi k, LivingEntity target) {
        if (k.ki < 15) {
            msg(p, "Not enough ki for Vanish Strike.");
            return;
        }
        ServerLevel lvl = p.serverLevel();
        Vec3 behind = target.position().subtract(Vec3.directionFromRotation(0.0f, target.getYRot()).scale(1.6));
        AABB moved = p.getBoundingBox().move(behind.subtract(p.position()));
        if (!lvl.noCollision(p, moved)) {
            msg(p, "No room behind the target.");
            return;
        }
        k.ki -= 15;
        lvl.sendParticles(ParticleTypes.REVERSE_PORTAL, p.getX(), p.getY() + 1.0, p.getZ(), 30, 0.3, 0.6, 0.3, 0.2);
        p.teleportTo(behind.x, behind.y, behind.z);
        p.lookAt(EntityAnchorArgument.Anchor.EYES, target.getEyePosition());
        lvl.sendParticles(ParticleTypes.REVERSE_PORTAL, behind.x, behind.y + 1.0, behind.z, 30, 0.3, 0.6, 0.3, 0.2);
        lvl.playSound(null, p.blockPosition(), SoundEvents.ENDERMAN_TELEPORT, SoundSource.PLAYERS, 1.0f, 1.8f);
        p.attack(target);
        k.addSpark(8);
        fx(p, 2, 6.0f);
    }

    private static void blink(ServerPlayer p, PlayerKi k) {
        if (k.ki < 12) {
            msg(p, "Not enough ki to blink.");
            return;
        }
        ServerLevel lvl = p.serverLevel();
        Vec3 dir = p.getLookAngle();
        Vec3 eye = p.getEyePosition();
        double maxDist = 16.0;
        BlockHitResult hit = lvl.clip(new ClipContext(eye, eye.add(dir.scale(maxDist)),
                ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, p));
        if (hit.getType() != HitResult.Type.MISS) maxDist = eye.distanceTo(hit.getLocation());

        for (double d = maxDist; d >= 1.5; d -= 1.0) {
            AABB moved = p.getBoundingBox().move(dir.scale(d));
            if (lvl.noCollision(p, moved)) {
                lvl.sendParticles(ParticleTypes.REVERSE_PORTAL, p.getX(), p.getY() + 1.0, p.getZ(), 30, 0.3, 0.6, 0.3, 0.2);
                Vec3 to = p.position().add(dir.scale(d));
                p.teleportTo(to.x, to.y, to.z);
                p.fallDistance = 0;
                lvl.sendParticles(ParticleTypes.REVERSE_PORTAL, to.x, to.y + 1.0, to.z, 30, 0.3, 0.6, 0.3, 0.2);
                lvl.playSound(null, p.blockPosition(), SoundEvents.ENDERMAN_TELEPORT, SoundSource.PLAYERS, 1.0f, 1.5f);
                k.ki -= 12;
                return;
            }
        }
        msg(p, "No room to blink there.");
    }
}
