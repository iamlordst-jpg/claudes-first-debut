package com.saiyanlegacy;

import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModEntities {
    public static final DeferredRegister<EntityType<?>> ENTITIES =
            DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, SaiyanLegacy.MODID);

    public static final RegistryObject<EntityType<KiBlastEntity>> KI_BLAST = ENTITIES.register("ki_blast",
            () -> EntityType.Builder.<KiBlastEntity>of(KiBlastEntity::new, MobCategory.MISC)
                    .sized(0.5f, 0.5f)
                    .clientTrackingRange(4)
                    .updateInterval(10)
                    .build("ki_blast"));

    public static final RegistryObject<EntityType<Saibaman>> SAIBAMAN = ENTITIES.register("saibaman",
            () -> EntityType.Builder.<Saibaman>of(Saibaman::new, MobCategory.MONSTER)
                    .sized(0.7f, 1.5f)
                    .clientTrackingRange(8)
                    .build("saibaman"));
}
