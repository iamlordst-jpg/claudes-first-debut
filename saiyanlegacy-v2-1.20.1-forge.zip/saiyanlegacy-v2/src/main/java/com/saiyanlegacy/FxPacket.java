package com.saiyanlegacy;

import java.util.function.Supplier;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.network.NetworkEvent;

/** Screen effects: type 0 = camera shake, 1 = white flash, 2 = FOV punch. */
public class FxPacket {
    private final int type;
    private final float amount;

    public FxPacket(int type, float amount) {
        this.type = type;
        this.amount = amount;
    }

    public static void encode(FxPacket m, FriendlyByteBuf buf) {
        buf.writeInt(m.type);
        buf.writeFloat(m.amount);
    }

    public static FxPacket decode(FriendlyByteBuf buf) {
        return new FxPacket(buf.readInt(), buf.readFloat());
    }

    public static void handle(FxPacket m, Supplier<NetworkEvent.Context> ctx) {
        NetworkEvent.Context c = ctx.get();
        c.enqueueWork(() -> ClientFx.apply(m.type, m.amount));
        c.setPacketHandled(true);
    }
}
