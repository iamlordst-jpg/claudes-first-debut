package com.saiyanlegacy;

/** Plain holder for screen effects (camera shake, flash, FOV punch). Decayed by the client tick. */
public class ClientFx {
    public static float shake;
    public static float flash;
    public static float fov;

    public static void apply(int type, float amount) {
        switch (type) {
            case 0 -> shake = Math.max(shake, amount);
            case 1 -> flash = Math.max(flash, amount);
            case 2 -> fov = Math.max(fov, amount);
            default -> { }
        }
    }

    public static void decay() {
        shake *= 0.9f;
        flash *= 0.88f;
        fov *= 0.9f;
        if (shake < 0.01f) shake = 0;
        if (flash < 0.01f) flash = 0;
        if (fov < 0.05f) fov = 0;
    }
}
