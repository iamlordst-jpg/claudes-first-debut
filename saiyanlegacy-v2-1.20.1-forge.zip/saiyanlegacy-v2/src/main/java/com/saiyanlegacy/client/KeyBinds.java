package com.saiyanlegacy.client;

import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.KeyMapping;
import net.minecraftforge.client.settings.KeyConflictContext;
import org.lwjgl.glfw.GLFW;

public class KeyBinds {
    private static final String CAT = "key.categories.saiyanlegacy";

    public static final KeyMapping CHARGE = make("charge", GLFW.GLFW_KEY_C);
    public static final KeyMapping BLAST = make("blast", GLFW.GLFW_KEY_Z);
    public static final KeyMapping SPECIAL = make("special", GLFW.GLFW_KEY_G);
    public static final KeyMapping CYCLE = make("cycle", GLFW.GLFW_KEY_N);
    public static final KeyMapping UP = make("up", GLFW.GLFW_KEY_X);
    public static final KeyMapping DOWN = make("down", GLFW.GLFW_KEY_B);
    public static final KeyMapping FLY = make("fly", GLFW.GLFW_KEY_R);
    public static final KeyMapping DASH = make("dash", GLFW.GLFW_KEY_V);
    public static final KeyMapping GUARD = make("guard", GLFW.GLFW_KEY_H);
    public static final KeyMapping KAIOKEN = make("kaioken", GLFW.GLFW_KEY_K);
    public static final KeyMapping SPARKING = make("sparking", GLFW.GLFW_KEY_Y);

    private static KeyMapping make(String name, int key) {
        return new KeyMapping("key.saiyanlegacy." + name, KeyConflictContext.IN_GAME,
                InputConstants.Type.KEYSYM, key, CAT);
    }
}
