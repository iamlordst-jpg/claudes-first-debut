package com.saiyanlegacy.client;

import com.saiyanlegacy.ModEntities;
import com.saiyanlegacy.SaiyanLegacy;
import net.minecraft.client.renderer.entity.ThrownItemRenderer;
import net.minecraft.client.renderer.entity.player.PlayerRenderer;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.client.event.RegisterGuiOverlaysEvent;
import net.minecraftforge.client.event.RegisterKeyMappingsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = SaiyanLegacy.MODID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class ClientModEvents {
    @SubscribeEvent
    public static void registerKeys(RegisterKeyMappingsEvent event) {
        event.register(KeyBinds.CHARGE);
        event.register(KeyBinds.BLAST);
        event.register(KeyBinds.SPECIAL);
        event.register(KeyBinds.CYCLE);
        event.register(KeyBinds.UP);
        event.register(KeyBinds.DOWN);
        event.register(KeyBinds.FLY);
        event.register(KeyBinds.DASH);
        event.register(KeyBinds.GUARD);
        event.register(KeyBinds.KAIOKEN);
        event.register(KeyBinds.SPARKING);
    }

    @SubscribeEvent
    public static void registerRenderers(EntityRenderersEvent.RegisterRenderers event) {
        event.registerEntityRenderer(ModEntities.KI_BLAST.get(), ctx -> new ThrownItemRenderer<>(ctx, 1.5f, true));
        event.registerEntityRenderer(ModEntities.SAIBAMAN.get(), SaibamanRenderer::new);
    }

    @SubscribeEvent
    public static void registerLayerDefinitions(EntityRenderersEvent.RegisterLayerDefinitions event) {
        event.registerLayerDefinition(HairLayer.LAYER, HairLayer::createLayer);
        event.registerLayerDefinition(AuraLayer.LAYER, AuraLayer::createLayer);
    }

    @SubscribeEvent
    public static void addLayers(EntityRenderersEvent.AddLayers event) {
        for (String skin : new String[]{"default", "slim"}) {
            PlayerRenderer renderer = event.getSkin(skin);
            if (renderer != null) {
                renderer.addLayer(new AuraLayer(renderer, event.getEntityModels()));
                renderer.addLayer(new HairLayer(renderer, event.getEntityModels()));
            }
        }
    }

    @SubscribeEvent
    public static void registerOverlays(RegisterGuiOverlaysEvent event) {
        event.registerAboveAll("ki_hud", new KiHud());
        event.registerAboveAll("ki_flash", new FlashOverlay());
    }
}
