package com.saiyanlegacy.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import com.saiyanlegacy.ActionPacket;
import com.saiyanlegacy.ActionPacket.Action;
import com.saiyanlegacy.ClientFx;
import com.saiyanlegacy.ClientPlayerStates;
import com.saiyanlegacy.ModNetwork;
import com.saiyanlegacy.SaiyanLegacy;
import net.minecraft.client.Minecraft;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.player.Player;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.ClientPlayerNetworkEvent;
import net.minecraftforge.client.event.RenderPlayerEvent;
import net.minecraftforge.client.event.ViewportEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = SaiyanLegacy.MODID, value = Dist.CLIENT)
public class ClientForgeEvents {
    private static boolean charging;
    private static boolean special;
    private static boolean guard;

    private static void send(Action a) {
        ModNetwork.toServer(new ActionPacket(a));
    }

    // ------------------------------------------------------------------ input

    @SubscribeEvent
    public static void onClientTick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;
        ClientFx.decay();

        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) {
            charging = false;
            special = false;
            guard = false;
            return;
        }

        boolean inGame = mc.screen == null;
        boolean wantCharge = inGame && KeyBinds.CHARGE.isDown();
        boolean wantSpecial = inGame && KeyBinds.SPECIAL.isDown();
        boolean wantGuard = inGame && KeyBinds.GUARD.isDown();

        if (wantCharge != charging) {
            charging = wantCharge;
            send(charging ? Action.CHARGE_START : Action.CHARGE_STOP);
        }
        if (wantSpecial != special) {
            special = wantSpecial;
            send(special ? Action.SPECIAL_START : Action.SPECIAL_RELEASE);
        }
        if (wantGuard != guard) {
            guard = wantGuard;
            send(guard ? Action.GUARD_START : Action.GUARD_STOP);
        }

        if (!inGame) return;
        while (KeyBinds.BLAST.consumeClick()) send(Action.BLAST);
        while (KeyBinds.CYCLE.consumeClick()) send(Action.CYCLE_SPECIAL);
        while (KeyBinds.UP.consumeClick()) send(Action.TRANSFORM_UP);
        while (KeyBinds.DOWN.consumeClick()) send(Action.TRANSFORM_DOWN);
        while (KeyBinds.FLY.consumeClick()) send(Action.TOGGLE_FLY);
        while (KeyBinds.DASH.consumeClick()) send(Action.DASH);
        while (KeyBinds.KAIOKEN.consumeClick()) send(Action.KAIOKEN);
        while (KeyBinds.SPARKING.consumeClick()) send(Action.SPARKING);
    }

    @SubscribeEvent
    public static void onLogout(ClientPlayerNetworkEvent.LoggingOut event) {
        ClientPlayerStates.clear();
    }

    // ------------------------------------------------------------------ camera effects

    @SubscribeEvent
    public static void onCameraAngles(ViewportEvent.ComputeCameraAngles event) {
        float s = ClientFx.shake;
        if (s <= 0.01f) return;
        event.setPitch(event.getPitch() + (float) (Math.random() - 0.5) * s * 3.0f);
        event.setYaw(event.getYaw() + (float) (Math.random() - 0.5) * s * 3.0f);
        event.setRoll(event.getRoll() + (float) (Math.random() - 0.5) * s * 4.0f);
    }

    @SubscribeEvent
    public static void onFov(ViewportEvent.ComputeFov event) {
        if (ClientFx.fov > 0.05f) event.setFOV(event.getFOV() + ClientFx.fov);
    }

    // ------------------------------------------------------------------ animation: flight lean / charge lean

    private static float leanFor(Player p) {
        int bits = ClientPlayerStates.get(p.getId());
        if ((bits & ClientPlayerStates.FLYING) != 0 && !p.onGround()) {
            double speed = p.getDeltaMovement().horizontalDistance();
            return (float) -(10.0 + Math.min(65.0, speed * 140.0));
        }
        if ((bits & ClientPlayerStates.SPECIAL) != 0) return 12.0f;
        return 0.0f;
    }

    @SubscribeEvent
    public static void onRenderPlayerPre(RenderPlayerEvent.Pre event) {
        Player p = event.getEntity();
        float lean = leanFor(p);
        if (lean == 0.0f) return;
        PoseStack ps = event.getPoseStack();
        float yaw = Mth.rotLerp(event.getPartialTick(), p.yBodyRotO, p.yBodyRot);
        ps.pushPose();
        ps.translate(0.0, 0.9, 0.0);
        ps.mulPose(Axis.YP.rotationDegrees(180.0f - yaw));
        ps.mulPose(Axis.XP.rotationDegrees(lean));
        ps.mulPose(Axis.YP.rotationDegrees(-(180.0f - yaw)));
        ps.translate(0.0, -0.9, 0.0);
    }

    @SubscribeEvent
    public static void onRenderPlayerPost(RenderPlayerEvent.Post event) {
        if (leanFor(event.getEntity()) != 0.0f) event.getPoseStack().popPose();
    }
}
