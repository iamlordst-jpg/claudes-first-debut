package com.saiyanlegacy.client;

import com.saiyanlegacy.Saibaman;
import com.saiyanlegacy.SaiyanLegacy;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.resources.ResourceLocation;
import software.bernie.geckolib.model.DefaultedEntityGeoModel;
import software.bernie.geckolib.renderer.GeoEntityRenderer;

public class SaibamanRenderer extends GeoEntityRenderer<Saibaman> {
    public SaibamanRenderer(EntityRendererProvider.Context ctx) {
        super(ctx, new DefaultedEntityGeoModel<>(new ResourceLocation(SaiyanLegacy.MODID, "saibaman")));
    }
}
