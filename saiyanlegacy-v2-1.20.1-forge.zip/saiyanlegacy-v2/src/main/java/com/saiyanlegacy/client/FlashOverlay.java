package com.saiyanlegacy.client;

import com.saiyanlegacy.ClientFx;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.util.Mth;
import net.minecraftforge.client.gui.overlay.ForgeGui;
import net.minecraftforge.client.gui.overlay.IGuiOverlay;

public class FlashOverlay implements IGuiOverlay {
    @Override
    public void render(ForgeGui gui, GuiGraphics g, float partialTick, int width, int height) {
        if (ClientFx.flash < 0.02f) return;
        int alpha = (int) (255 * Mth.clamp(ClientFx.flash, 0.0f, 1.0f));
        g.fill(0, 0, width, height, (alpha << 24) | 0xFFFFFF);
    }
}
