package com.saiyanlegacy.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.saiyanlegacy.ClientPlayerStates;
import com.saiyanlegacy.Form;
import com.saiyanlegacy.SaiyanLegacy;
import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.model.geom.EntityModelSet;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.RenderLayerParent;
import net.minecraft.client.renderer.entity.layers.RenderLayer;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;

/** Glowing spiky hair that appears on the player's head while transformed. */
public class HairLayer extends RenderLayer<AbstractClientPlayer, PlayerModel<AbstractClientPlayer>> {
    public static final ModelLayerLocation LAYER =
            new ModelLayerLocation(new ResourceLocation(SaiyanLegacy.MODID, "hair"), "main");
    private static final ResourceLocation TEX = new ResourceLocation(SaiyanLegacy.MODID, "textures/layer/hair.png");

    private final ModelPart hair;
    private final ModelPart longHair;

    public HairLayer(RenderLayerParent<AbstractClientPlayer, PlayerModel<AbstractClientPlayer>> parent, EntityModelSet models) {
        super(parent);
        ModelPart root = models.bakeLayer(LAYER);
        this.hair = root.getChild("hair");
        this.longHair = this.hair.getChild("long");
    }

    public static LayerDefinition createLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
        PartDefinition hair = root.addOrReplaceChild("hair", CubeListBuilder.create(), PartPose.ZERO);
        hair.addOrReplaceChild("cap", CubeListBuilder.create().texOffs(0, 0)
                .addBox(-4.5f, -9.0f, -4.5f, 9.0f, 2.0f, 9.0f), PartPose.ZERO);
        hair.addOrReplaceChild("front", CubeListBuilder.create().texOffs(0, 0)
                .addBox(-1.5f, -14.0f, -4.5f, 3.0f, 6.0f, 3.0f), PartPose.rotation(-0.4f, 0.0f, 0.0f));
        hair.addOrReplaceChild("back", CubeListBuilder.create().texOffs(0, 0)
                .addBox(-1.5f, -14.0f, 1.5f, 3.0f, 6.0f, 3.0f), PartPose.rotation(0.4f, 0.0f, 0.0f));
        hair.addOrReplaceChild("left", CubeListBuilder.create().texOffs(0, 0)
                .addBox(2.5f, -13.0f, -1.5f, 3.0f, 5.0f, 3.0f), PartPose.rotation(0.0f, 0.0f, 0.45f));
        hair.addOrReplaceChild("right", CubeListBuilder.create().texOffs(0, 0)
                .addBox(-5.5f, -13.0f, -1.5f, 3.0f, 5.0f, 3.0f), PartPose.rotation(0.0f, 0.0f, -0.45f));
        hair.addOrReplaceChild("mid", CubeListBuilder.create().texOffs(0, 0)
                .addBox(-1.5f, -17.0f, -1.5f, 3.0f, 8.0f, 3.0f), PartPose.ZERO);
        hair.addOrReplaceChild("long", CubeListBuilder.create().texOffs(0, 0)
                .addBox(-3.5f, -8.0f, 3.5f, 7.0f, 15.0f, 2.0f), PartPose.ZERO);
        return LayerDefinition.create(mesh, 64, 64);
    }

    @Override
    public void render(PoseStack ps, MultiBufferSource buf, int light, AbstractClientPlayer p,
                       float limbSwing, float limbSwingAmount, float partialTick, float ageInTicks,
                       float netHeadYaw, float headPitch) {
        if (p.isInvisible()) return;
        Form f = Form.byId((ClientPlayerStates.get(p.getId()) >> 8) & 0xFF);
        if (f.hairStyle == 0) return;

        float r = ((f.hairColor >> 16) & 0xFF) / 255.0f;
        float g = ((f.hairColor >> 8) & 0xFF) / 255.0f;
        float b = (f.hairColor & 0xFF) / 255.0f;

        ps.pushPose();
        getParentModel().head.translateAndRotate(ps);
        longHair.visible = f.hairStyle == 2;
        VertexConsumer vc = buf.getBuffer(RenderType.entityCutoutNoCull(TEX));
        hair.render(ps, vc, LightTexture.FULL_BRIGHT, OverlayTexture.NO_OVERLAY, r, g, b, 1.0f);
        ps.popPose();
    }
}
