package com.saiyanlegacy.client;

import com.saiyanlegacy.ClientKiData;
import com.saiyanlegacy.ClientPlayerStates;
import com.saiyanlegacy.Form;
import com.saiyanlegacy.Special;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.util.Mth;
import net.minecraftforge.client.gui.overlay.ForgeGui;
import net.minecraftforge.client.gui.overlay.IGuiOverlay;

public class KiHud implements IGuiOverlay {
    @Override
    public void render(ForgeGui gui, GuiGraphics g, float partialTick, int width, int height) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.options.hideGui || mc.player == null || mc.player.isSpectator()) return;
        Font font = mc.font;

        int x = 10;
        int y = height - 66;
        int barW = 110;
        Form form = Form.byId(ClientKiData.formId());
        int bits = ClientKiData.bits;
        boolean sparking = ClientKiData.sparkingTicks > 0;

        // ki bar
        double ratio = ClientKiData.maxKi <= 0 ? 0 : Mth.clamp(ClientKiData.ki / ClientKiData.maxKi, 0.0, 1.0);
        g.fill(x - 1, y - 1, x + barW + 1, y + 9, 0xAA000000);
        g.fill(x, y, x + (int) (barW * ratio), y + 8, 0xFF000000 | (form == Form.BASE ? 0x2E9BFF : form.hudColor));
        g.drawString(font, "Ki " + (int) ClientKiData.ki + "/" + (int) ClientKiData.maxKi, x, y - 11, 0xFFFFFFFF);

        // sparking meter
        int sy = y + 13;
        double sr = sparking ? Mth.clamp(ClientKiData.sparkingTicks / 600.0, 0.0, 1.0) : Mth.clamp(ClientKiData.spark / 100.0, 0.0, 1.0);
        int sparkColor = sparking ? 0xFFFFE066 : (ClientKiData.spark >= 100 ? 0xFFFFC800 : 0xFFB8860B);
        g.fill(x - 1, sy - 1, x + barW + 1, sy + 5, 0xAA000000);
        g.fill(x, sy, x + (int) (barW * sr), sy + 4, sparkColor);
        String sparkText = sparking ? "SPARKING! " + (ClientKiData.sparkingTicks / 20) + "s"
                : (ClientKiData.spark >= 100 ? "SPARKING READY [Y]" : "Sparking " + (int) ClientKiData.spark + "%");
        g.drawString(font, sparkText, x + barW + 6, sy - 2, sparkColor);

        // text lines
        g.drawString(font, "PL " + String.format("%,d", ClientKiData.power), x, y + 22, 0xFFFFD700);
        g.drawString(font, form.displayName, x, y + 32, 0xFF000000 | form.hudColor);
        Special sp = Special.values()[Mth.clamp(ClientKiData.special, 0, Special.values().length - 1)];
        g.drawString(font, "[N] " + sp.displayName, x, y + 42, 0xFFCCCCCC);

        StringBuilder status = new StringBuilder();
        if ((bits & ClientPlayerStates.CHARGING) != 0) status.append("[Charging] ");
        if ((bits & ClientPlayerStates.FLYING) != 0) status.append("[Flying] ");
        if ((bits & ClientPlayerStates.KAIOKEN) != 0) status.append("[Kaioken] ");
        if ((bits & ClientPlayerStates.GUARD) != 0) status.append("[Guard]");
        if (status.length() > 0) g.drawString(font, status.toString(), x, y + 52, 0xFFAAAAAA);
    }
}
