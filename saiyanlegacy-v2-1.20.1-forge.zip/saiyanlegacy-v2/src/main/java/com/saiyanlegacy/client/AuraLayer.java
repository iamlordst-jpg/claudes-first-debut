package com.saiyanlegacy.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.saiyanlegacy.ClientPlayerStates;
import com.saiyanlegacy.Form;
import com.saiyanlegacy.SaiyanLegacy;
import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.model.geom.EntityModelSet;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.model.geom.builders.CubeDeformation;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.RenderLayerParent;
import net.minecraft.client.renderer.entity.layers.RenderLayer;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;

/** Swirling energy shell around the player (Sparking-style aura). */
public class AuraLayer extends RenderLayer<AbstractClientPlayer, PlayerModel<AbstractClientPlayer>> {
    public static final ModelLayerLocation LAYER =
            new ModelLayerLocation(new ResourceLocation(SaiyanLegacy.MODID, "aura"), "main");
    private static final ResourceLocation TEX = new ResourceLocation(SaiyanLegacy.MODID, "textures/layer/aura.png");

    private final PlayerModel<AbstractClientPlayer> model;

    public AuraLayer(RenderLayerParent<AbstractClientPlayer, PlayerModel<AbstractClientPlayer>> parent, EntityModelSet models) {
        super(parent);
        this.model = new PlayerModel<>(models.bakeLayer(LAYER), false);
    }

    public static LayerDefinition createLayer() {
        return LayerDefinition.create(PlayerModel.createMesh(new CubeDeformation(0.35f), false), 64, 64);
    }

    @Override
    public void render(PoseStack ps, MultiBufferSource buf, int light, AbstractClientPlayer p,
                       float limbSwing, float limbSwingAmount, float partialTick, float ageInTicks,
                       float netHeadYaw, float headPitch) {
        if (p.isInvisible()) return;
        int bits = ClientPlayerStates.get(p.getId());
        Form f = Form.byId((bits >> 8) & 0xFF);
        boolean sparking = (bits & ClientPlayerStates.SPARKING) != 0;
        boolean kaioken = (bits & ClientPlayerStates.KAIOKEN) != 0;
        boolean charging = (bits & (ClientPlayerStates.CHARGING | ClientPlayerStates.SPECIAL)) != 0;
        if (f == Form.BASE && !sparking && !kaioken && !charging) return;

        float[] c = f.aura;
        float alpha = 0.45f;
        if (kaioken) c = new float[]{1.0f, 0.12f, 0.08f};
        if (sparking) {
            float pulse = 0.5f + 0.5f * (float) Math.sin(ageInTicks * 0.5f);
            c = new float[]{1.0f, 0.85f + 0.15f * pulse, 0.3f + 0.7f * pulse};
            alpha = 0.6f;
        }
        if (charging) alpha += 0.15f;

        getParentModel().copyPropertiesTo(model);
        float u = (ageInTicks * 0.02f) % 1.0f;
        float v = (ageInTicks * 0.015f) % 1.0f;
        VertexConsumer vc = buf.getBuffer(RenderType.energySwirl(TEX, u, v));
        model.renderToBuffer(ps, vc, LightTexture.FULL_BRIGHT, OverlayTexture.NO_OVERLAY, c[0], c[1], c[2], alpha);
    }
}
