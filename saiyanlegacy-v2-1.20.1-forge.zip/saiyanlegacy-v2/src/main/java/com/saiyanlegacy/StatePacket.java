package com.saiyanlegacy;

import java.util.function.Supplier;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.network.NetworkEvent;

/** Broadcast to everyone tracking a player so their aura, hair and flight pose render for other clients. */
public class StatePacket {
    private final int entityId;
    private final int bits;

    public StatePacket(int entityId, int bits) {
        this.entityId = entityId;
        this.bits = bits;
    }

    public static void encode(StatePacket m, FriendlyByteBuf buf) {
        buf.writeInt(m.entityId);
        buf.writeInt(m.bits);
    }

    public static StatePacket decode(FriendlyByteBuf buf) {
        return new StatePacket(buf.readInt(), buf.readInt());
    }

    public static void handle(StatePacket m, Supplier<NetworkEvent.Context> ctx) {
        NetworkEvent.Context c = ctx.get();
        c.enqueueWork(() -> ClientPlayerStates.set(m.entityId, m.bits));
        c.setPacketHandled(true);
    }
}
