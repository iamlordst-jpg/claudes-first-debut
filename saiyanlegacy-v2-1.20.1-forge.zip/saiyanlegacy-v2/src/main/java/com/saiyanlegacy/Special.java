package com.saiyanlegacy;

public enum Special {
    KAMEHAMEHA("Kamehameha", Type.BEAM, new float[]{0.3f, 0.7f, 1.0f}, 0L, 1.0, 1.0, 1.0),
    GALICK_GUN("Galick Gun", Type.BEAM, new float[]{0.7f, 0.25f, 1.0f}, 500L, 1.15, 0.9, 1.1),
    FINAL_FLASH("Final Flash", Type.BEAM, new float[]{1.0f, 0.9f, 0.3f}, 5000L, 1.8, 1.6, 1.3),
    SPIRIT_BOMB("Spirit Bomb", Type.BOMB, new float[]{0.6f, 0.85f, 1.0f}, 3000L, 1.0, 1.0, 1.0),
    KI_BARRAGE("Ki Barrage", Type.BARRAGE, new float[]{1.0f, 0.8f, 0.4f}, 200L, 1.0, 1.0, 1.0),
    SOLAR_FLARE("Solar Flare", Type.FLARE, new float[]{1.0f, 1.0f, 0.8f}, 0L, 1.0, 1.0, 1.0);

    public enum Type { BEAM, BOMB, BARRAGE, FLARE }

    public final String displayName;
    public final Type type;
    public final float[] color;
    public final long minPower;
    public final double damageFactor;
    public final double widthFactor;
    public final double rangeFactor;

    Special(String displayName, Type type, float[] color, long minPower,
            double damageFactor, double widthFactor, double rangeFactor) {
        this.displayName = displayName;
        this.type = type;
        this.color = color;
        this.minPower = minPower;
        this.damageFactor = damageFactor;
        this.widthFactor = widthFactor;
        this.rangeFactor = rangeFactor;
    }

    public int maxTicks() {
        return switch (type) {
            case BOMB -> 200;
            case BARRAGE -> 60;
            default -> 100;
        };
    }

    public Special next() {
        Special[] v = values();
        return v[(ordinal() + 1) % v.length];
    }
}
