package com.saiyanlegacy;

public enum Form {
    //   name                 dmg  def  speed drain minPL    hud       aura rgb                     hair     style
    BASE("Base",              1.0, 1.0, 0.0,  0.0,  0L,      0xFFFFFF, new float[]{0.75f, 0.9f, 1.0f}, -1,      0),
    SUPER_SAIYAN("Super Saiyan",       2.0, 1.5, 0.40, 1.5, 1500L,   0xFFD700, new float[]{1.0f, 0.85f, 0.1f},  0xFFD73C, 1),
    SUPER_SAIYAN_2("Super Saiyan 2",   2.8, 2.0, 0.55, 2.2, 6000L,   0xFFE94D, new float[]{1.0f, 0.95f, 0.3f},  0xFFE24A, 1),
    SUPER_SAIYAN_3("Super Saiyan 3",   4.0, 2.6, 0.70, 4.0, 15000L,  0xFFC000, new float[]{1.0f, 0.75f, 0.05f}, 0xFFC81E, 2),
    SUPER_SAIYAN_GOD("Super Saiyan God", 5.0, 3.2, 0.80, 2.5, 40000L, 0xFF3030, new float[]{1.0f, 0.15f, 0.2f}, 0xE02828, 1),
    SUPER_SAIYAN_BLUE("Super Saiyan Blue", 6.5, 4.0, 0.95, 3.5, 80000L, 0x40C8FF, new float[]{0.2f, 0.6f, 1.0f}, 0x3CA8FF, 1),
    ULTRA_INSTINCT("Ultra Instinct",   9.0, 5.0, 1.20, 5.0, 160000L, 0xE6EBF5, new float[]{0.85f, 0.9f, 1.0f},  0xE1E6F0, 1);

    public final String displayName;
    public final double damage;
    public final double defense;
    public final double speed;
    public final double drain;
    public final long minPower;
    public final int hudColor;
    public final float[] aura;
    public final int hairColor;
    public final int hairStyle;

    Form(String displayName, double damage, double defense, double speed, double drain,
         long minPower, int hudColor, float[] aura, int hairColor, int hairStyle) {
        this.displayName = displayName;
        this.damage = damage;
        this.defense = defense;
        this.speed = speed;
        this.drain = drain;
        this.minPower = minPower;
        this.hudColor = hudColor;
        this.aura = aura;
        this.hairColor = hairColor;
        this.hairStyle = hairStyle;
    }

    public static Form byId(int id) {
        Form[] v = values();
        return v[Math.max(0, Math.min(v.length - 1, id))];
    }
}
