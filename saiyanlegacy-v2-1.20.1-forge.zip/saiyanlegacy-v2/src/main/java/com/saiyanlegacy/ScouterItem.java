package com.saiyanlegacy;

import java.util.List;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;

public class ScouterItem extends Item {
    public ScouterItem(Properties props) {
        super(props);
    }

    @Override
    public InteractionResult interactLivingEntity(ItemStack stack, Player player, LivingEntity target, InteractionHand hand) {
        if (!player.level().isClientSide() && player instanceof ServerPlayer sp) {
            long pl = (long) (target.getMaxHealth() * 10);
            if (target instanceof Player other) {
                PlayerKi k = PlayerKi.of(other);
                if (k != null) pl = k.power;
            }
            String text = "Scouter: " + target.getName().getString() + "  PL " + String.format("%,d", pl);
            if (pl > 9000) text += "  (It's over 9000!)";
            KiActions.msg(sp, text);
        }
        return InteractionResult.sidedSuccess(player.level().isClientSide());
    }

    @Override
    public void appendHoverText(ItemStack stack, Level level, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.literal("Right-click a creature to read its power level."));
    }
}
