package com.saiyanlegacy;

/** Plain holder for the local player's synced stats (read by the HUD). */
public class ClientKiData {
    public static double ki = 100;
    public static double maxKi = 120;
    public static long power = 100;
    public static float spark = 0;
    public static int sparkingTicks = 0;
    public static int special = 0;
    public static int bits = 0;

    public static void set(double ki, double maxKi, long power, float spark, int sparkingTicks, int special, int bits) {
        ClientKiData.ki = ki;
        ClientKiData.maxKi = maxKi;
        ClientKiData.power = power;
        ClientKiData.spark = spark;
        ClientKiData.sparkingTicks = sparkingTicks;
        ClientKiData.special = special;
        ClientKiData.bits = bits;
    }

    public static int formId() {
        return (bits >> 8) & 0xFF;
    }
}
